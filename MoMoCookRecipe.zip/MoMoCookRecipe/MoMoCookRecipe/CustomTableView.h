//
//  CustomTableView.h
//  MoMoCookRecipe
//
//  Created by F7686324 on 2016/12/9.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CustomTableView;
@protocol CustomTableViewDelegate <NSObject>

@required
-(void)customTableView:(CustomTableView *)customTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface CustomTableView : UIView <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, weak) id <CustomTableViewDelegate> delegate;

@end
