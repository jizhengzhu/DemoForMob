//
//  JZCookCategory.h
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZCookCategory : NSObject

@property (nonatomic, copy) NSArray *childs;
@property (nonatomic, copy) NSDictionary *categoryInfo;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)cookCategoryWithDict:(NSDictionary *)dict;

@end
