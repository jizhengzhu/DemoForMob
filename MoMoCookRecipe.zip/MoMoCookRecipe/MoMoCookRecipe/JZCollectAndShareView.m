//
//  JZCollectAndShareView.m
//  tf02
//
//  Created by F7686324 on 10/12/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZCollectAndShareView.h"
#import "ColorManager.h"
@implementation JZCollectAndShareView

- (UIButton *)collectBtn
{
    if (!_collectBtn) {
        _collectBtn = [[UIButton alloc] initWithFrame: CGRectMake(0, 0, 30, 44)];
        [_collectBtn setImage:[ColorManager manager].collect_NO forState:UIControlStateNormal];
    }
    return _collectBtn;
}

- (UIButton *)shareBtn
{
    if (!_shareBtn) {
        _shareBtn = [[UIButton alloc] initWithFrame: CGRectMake(30, 0, 30, 44)];
        [_shareBtn setImage:[ColorManager manager].shareImage forState: UIControlStateNormal];
    }
    return _shareBtn;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview: self.collectBtn];
        [self addSubview: self.shareBtn];
    }
    return self;
}

@end
