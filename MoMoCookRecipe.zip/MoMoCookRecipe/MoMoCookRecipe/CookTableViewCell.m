//
//  CookTableViewCell.m
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "CookTableViewCell.h"
#import "Utility.h"

@implementation CookTableViewCell

static CGFloat imageW = 64.f * 130.f / 96.f;

- (UIImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[UIImageView alloc] initWithFrame:CGRectMake(5, 8, imageW, 64)];
        _imgView.layer.cornerRadius = 4;
        _imgView.clipsToBounds = YES;
    }
    return _imgView;
}

- (UILabel *)name
{
    if (!_name) {
        _name = [[UILabel alloc] initWithFrame:CGRectMake(imageW + 10, 5, screenW - imageW - 35, 20)];
    }
    return _name;
}

- (UILabel *)sumary
{
    if (!_sumary) {
        _sumary = [[UILabel alloc] initWithFrame:CGRectMake(imageW + 10, 25, screenW - imageW - 35, 50)];
        _sumary.numberOfLines = 0;
        _sumary.font = [UIFont systemFontOfSize:15];

    }
    return _sumary;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self addSubview:self.imgView];
        [self addSubview:self.name];
        [self addSubview:self.sumary];
        self.separatorInset = UIEdgeInsetsMake(0, 5, 0, 0);
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return self;
}

+ (CookTableViewCell *)cellWithTableView:(UITableView *)tableView
{
    static NSString *cellid = @"CookTableViewCellID";
    CookTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell = [[CookTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
    }
    cell.name.textColor = [ColorManager manager].cell_textLabel_textColor;
    cell.sumary.textColor = [ColorManager manager].cell_sumary_textColor;
    cell.backgroundColor = [ColorManager manager].cell_backgroundColor;
    return cell;
}

@end
