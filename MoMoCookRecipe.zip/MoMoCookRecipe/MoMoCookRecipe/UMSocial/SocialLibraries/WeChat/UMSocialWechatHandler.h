//
//  UMSWechatDataTypeTableViewController.h
//  SocialSDK
//
//  Created by umeng on 16/4/14.
//  Copyright © 2016年 dongjianxiong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UMSocialCore/UMSocialCore.h>

@interface UMSocialWechatHandler : UMSocialHandler

+ (UMSocialWechatHandler *)defaultManager;

@end
