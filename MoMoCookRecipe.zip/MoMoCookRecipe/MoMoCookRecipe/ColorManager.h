//
//  ColorManager.h
//  MoMoCookRecipe
//
//  Created by Jim on 2016/12/9.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ColorManager : NSObject

@property (nonatomic, strong) UIColor *navigationBar_tintColor;
@property (nonatomic, strong) UIColor *navigationBar_barTintColor;
@property (nonatomic, strong) UIColor *navigationBar_titleColor;

@property (nonatomic, strong) UIColor *searchBar_tintColor;
@property (nonatomic, strong) UIColor *searchBar_barTintColor;
@property (nonatomic, strong) UIImage *searchBar_backgroundImage;

@property (nonatomic, strong) UIColor *statusView_backgroundColor;

@property (nonatomic, assign) UIBarStyle tabBar_barStyle;
@property (nonatomic, strong) UIColor *tabBar_tintColor;
@property (nonatomic, strong) UIColor *tabBar_barTintColor;
@property (nonatomic, strong) UIImage *tabBar_backgroundImage;

@property (nonatomic, strong) UIVisualEffect *searchView_effect;


@property (nonatomic, strong) UIColor *cell_backgroundColor;
@property (nonatomic, strong) UIColor *cell_textLabel_textColor;
@property (nonatomic, strong) UIColor *cell_label_textColor;
@property (nonatomic, strong) UIColor *cell_sumary_textColor;
@property (nonatomic, strong) UIColor *cell_ingredients_textColor;

@property (nonatomic, strong) UIColor *customTBView_cell_textColor;

@property (nonatomic, strong) UIColor *tbView_separatorColor;
@property (nonatomic, assign) UIScrollViewIndicatorStyle tbView_indicatorStyle;

@property (nonatomic, assign) UIActivityIndicatorViewStyle activity_indicatorStyle;


@property (nonatomic, strong) UIColor *app_backgroundColor;

@property (nonatomic, strong) UIImage *tabBar_cook_image;
@property (nonatomic, strong) UIImage *tabBar_cook_selectedImage;

@property (nonatomic, strong) UIImage *tabBar_more_image;
@property (nonatomic, strong) UIImage *tabBar_more_selectedImage;

@property (nonatomic, strong) UIImage *shareImage;
@property (nonatomic, strong) UIImage *collect_YES;
@property (nonatomic, strong) UIImage *collect_NO;

@property (nonatomic, assign) UIBarStyle sheet_share_barStyle;
@property (nonatomic, assign) UIBarStyle sheet_model_barStyle;

+ (ColorManager *)manager;
- (void)setNightStyle;
- (void)setDayStyle;

@end
