//
//  JZModel.m
//  MoMoCookRecipe
//
//  Created by F7686324 on 2016/12/14.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZModel.h"

@implementation JZModel

+ (instancetype)modelWithThumbnail:(NSString *)thumbnail name:(NSString *)name sumary:(NSString *)sumary menuId:(NSString *)menuId recipe:(NSString *)recipe
{
    JZModel *model = [[JZModel alloc] init];
    model.thumbnail = thumbnail;
    model.name = name;
    model.sumary = sumary;
    model.recipe = recipe;
    model.menuId = menuId;
    return model;
    
}

@end
