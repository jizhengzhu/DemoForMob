//
//  NSString+JSONDictionary.h
//  MoMoCookRecipe
//
//  Created by F7686324 on 2016/12/14.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (JSONDictionary)

- (NSDictionary *)JSONDictionary;

@end
