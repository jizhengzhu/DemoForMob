//
//  CollectionViewController.m
//  CookRecipe
//
//  Created by Jim on 2016/12/7.
//  Copyright © 2016年 Jim.com. All rights reserved.
//

#import "CollectionViewController.h"
#import "Utility.h"
#import "JZCookMenu.h"
#import "JZCookRecipe.h"
#import "NSArray+changeOrder.h"
#import "CookTableViewCell.h"
#import "CookDetailViewController.h"
#import "JZFmdbTool.h"

@interface CollectionViewController () <UITableViewDelegate, UITableViewDataSource, UIViewControllerPreviewingDelegate>

@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, strong) NSMutableArray *cookMenuArray;
@property (nonatomic, strong) NSMutableArray *cookRecipeArray;
@property (nonatomic, strong) UILabel *tips;

@end

@implementation CollectionViewController

- (NSMutableArray *)cookMenuArray
{
    if (!_cookMenuArray) {
        _cookMenuArray = [NSMutableArray array];
    }
    return _cookMenuArray;
}

- (NSMutableArray *)cookRecipeArray
{
    if (!_cookRecipeArray) {
        _cookRecipeArray = [NSMutableArray array];
        
    }
    return _cookRecipeArray;
}

- (UILabel *)tips
{
    if (!_tips) {
        _tips = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH - statusHeight - naviHeight)];
        _tips.text = @"暂未收藏菜谱~";
        _tips.textAlignment = NSTextAlignmentCenter;
    }
    return _tips;
}

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH)];
        _tbView.backgroundColor = [UIColor clearColor];
        _tbView.dataSource = self;
        _tbView.delegate = self;
        _tbView.separatorInset = UIEdgeInsetsMake(0, screenW, 0, 0);
    }
    return _tbView;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self changeAppBackgroundStyle];
    [self updateCollection];
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [LCProgressHUD hide];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的收藏";
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    [self.view addSubview:self.tbView];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateCollection) name:updateCollectionNotification object:nil];
}

- (void)changeAppBackgroundStyle
{
    self.tips.textColor = [ColorManager manager].cell_sumary_textColor;
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    [self.tbView reloadData];
}

- (void)updateCollection
{
    NSArray *arr = [JZFmdbTool queryData:nil];
    arr = [arr changeOrder];
    
    [self.cookMenuArray removeAllObjects];
    [self.cookRecipeArray removeAllObjects];
    for (JZModel *model in arr) {
        JZCookMenu *cookMenu = [JZCookMenu cookMenuWithMenuId:model.menuId
                                                         name:model.name
                                                    thumbnail:model.thumbnail
                                                       recipe:model.recipe];
        JZCookRecipe *cookRecipe = [JZCookRecipe cookRecipeWithDict:cookMenu.recipe];
        [self.cookMenuArray addObject:cookMenu];
        [self.cookRecipeArray addObject:cookRecipe];
    }

    [self.tbView reloadData];
    
    if (!self.cookMenuArray.count) {
        [self.tbView addSubview:self.tips];
    } else {
        [self.tips removeFromSuperview];
    }
}

#pragma mark UITableViewDelegate,UITableViewDataSource Methods
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CookTableViewCell *cell = [CookTableViewCell cellWithTableView:tableView];
    JZCookRecipe *cookRecipe = self.cookRecipeArray[indexPath.row];
    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    [cell.imgView sd_setImageWithURL:[NSURL URLWithString:cookMenu.thumbnail] placeholderImage:[UIImage imageNamed:@"replaceImage"]];
    if (self.traitCollection.forceTouchCapability == UIForceTouchCapabilityAvailable) {
        [self registerForPreviewingWithDelegate:self sourceView:cell];
    }
    cell.name.text = cookMenu.name;
    cell.sumary.text = cookRecipe.sumary;
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.cookMenuArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    CookDetailViewController *cookDetailVC = [[CookDetailViewController alloc] init];
    
    JZCookRecipe *cookRecipe = self.cookRecipeArray[indexPath.row];
    cookDetailVC.cookRecipe = cookRecipe;
    
    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    cookDetailVC.cookMenu = cookMenu;
    
    [self.navigationController pushViewController:cookDetailVC animated:YES];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    JZCookRecipe *cookRecipe = self.cookRecipeArray[indexPath.row];

    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSString *value = [self distinguishCollectionStatusByCookMenu:cookMenu];
        [self distinguishCollecionOperationByValue:value cookMenu:cookMenu cookRecipe:cookRecipe];
        [self.cookMenuArray removeObjectAtIndex:indexPath.row];
        [self.cookRecipeArray removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {

    }
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    NSString *value = [self distinguishCollectionStatusByCookMenu:cookMenu];

    return value;
}
#pragma mark 鉴别是否收藏
- (NSString *)distinguishCollectionStatusByCookMenu:(JZCookMenu *)cookMenu
{
    NSString *querySql = [NSString stringWithFormat:@"SELECT * FROM jz_models WHERE menuId = '%@'", cookMenu.menuId];
    NSArray *arr = [JZFmdbTool queryData:querySql];

    NSString *value = @"收藏";
    if (arr.count) {
        value = @"取消收藏";
    }

    return value;
}

#pragma mark 根据收藏状态执行相应操作
- (void)distinguishCollecionOperationByValue:(NSString *)value cookMenu:(JZCookMenu *)cookMenu cookRecipe:(JZCookRecipe *)cookRecipe
{
    if ([value isEqualToString:@"收藏"]) {
        JZModel *model = [JZModel modelWithThumbnail:cookMenu.thumbnail
                                                name:cookMenu.name
                                              sumary:cookRecipe.sumary
                                              menuId:cookMenu.menuId
                                              recipe:[cookMenu.recipe JSONString]];
        [JZFmdbTool insertModel:model];
        [LCProgressHUD showInfoMsg:@"收藏成功"];
    } else if ([value isEqualToString:@"取消收藏"]) {
        NSString *deleteSql = [NSString stringWithFormat:@"DELETE FROM jz_models WHERE menuId = '%@'", cookMenu.menuId];
        [JZFmdbTool deleteData:deleteSql];
        [LCProgressHUD showInfoMsg:@"取消收藏成功"];
    }
}

#pragma mark UIViewControllerPreviewingDelegate Methods
//peek(预览)
- (nullable UIViewController *)previewingContext:(id<UIViewControllerPreviewing>)previewingContext viewControllerForLocation:(CGPoint)location
{
    //获取按压的cell所在行， [previewingContext sourceView]就是按压的那个视图
    NSIndexPath *indexPath = [self.tbView indexPathForCell:(UITableViewCell *)[previewingContext sourceView]];

    //设定预览的界面
    CookDetailViewController *cookDetailVC = [[CookDetailViewController alloc] init];
    JZCookRecipe *cookRecipe = self.cookRecipeArray[indexPath.row];
    cookDetailVC.cookRecipe = cookRecipe;

    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    cookDetailVC.cookMenu = cookMenu;

    //调整不被虚化的范围，按压的那个cell不被虚化（轻轻按压时周边会被虚化，再稍用力展示预览，再加力跳页至设定界面)
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width, 80);
    previewingContext.sourceRect = rect;

    //返回预览界面
    return cookDetailVC;
}

//pop (再加力进入)
- (void)previewingContext:(id<UIViewControllerPreviewing>)previewingContext commitViewController:(UIViewController *)viewControllerToCommit
{
    [self showViewController:viewControllerToCommit sender:self];
}
@end
