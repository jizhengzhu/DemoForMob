//
//  ColorManager.m
//  MoMoCookRecipe
//
//  Created by Jim on 2016/12/9.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "ColorManager.h"
#import "Utility.h"

@implementation ColorManager

+(ColorManager *)manager
{
    static ColorManager *colorManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        colorManager = [[ColorManager alloc] init];
        
    });
    return colorManager;
}

- (void)setDayStyle
{
    self.navigationBar_tintColor = [UIColor whiteColor];
    self.navigationBar_barTintColor = [UIColor blackColor];
    self.navigationBar_titleColor = [UIColor whiteColor];
    
    self.searchBar_tintColor = [UIColor colorWithRed:0.00 green:0.68 blue:0.17 alpha:1.00];
    self.searchBar_barTintColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
    UIImage *image = [UIImage imageNamed:@"dayBg"];
    UIImage *backgroundImage = [self cutImage:image];
    self.searchBar_backgroundImage = backgroundImage;
    self.statusView_backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];

//    UIImage *tabBarImage = [UIImage imageNamed:@"dayTabBarBg"];
//    UIImage *tabBarBackgroundImage = [self cutImage:tabBarImage];
    self.tabBar_tintColor = [UIColor colorWithRed:0.00 green:0.68 blue:0.17 alpha:1.00];
    self.tabBar_barTintColor = nil;
    self.tabBar_backgroundImage = nil;
    self.tabBar_barStyle = UIBarStyleDefault;
    
    self.searchView_effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
    
    self.tbView_separatorColor = [UIColor colorWithWhite:0.85 alpha:1];
    self.tbView_indicatorStyle = UIScrollViewIndicatorStyleBlack;
    
    self.activity_indicatorStyle = UIActivityIndicatorViewStyleGray;
    
    self.cell_backgroundColor = [UIColor whiteColor];
    self.cell_label_textColor = [UIColor blackColor];
    self.cell_sumary_textColor = [UIColor grayColor];
    self.cell_textLabel_textColor = [UIColor blackColor];
    self.cell_ingredients_textColor = [UIColor blueColor];
    
    self.customTBView_cell_textColor = [UIColor blackColor];
    
    self.app_backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
    
    self.tabBar_cook_image = [UIImage imageNamed:@"tabBar_cook_image_day"];
    self.tabBar_cook_selectedImage = [UIImage imageNamed:@"tabBar_cook_selectedImage_day"];
    
    self.tabBar_more_image = [UIImage imageNamed:@"tabBar_more_image_day"];
    self.tabBar_cook_selectedImage = [UIImage imageNamed:@"tabBar_cook_selectedImage_day"];
    
    self.shareImage = [UIImage imageNamed:@"shareImage_day"];
    self.collect_NO = [UIImage imageNamed:@"collect_NO_day"];
    self.collect_YES = [UIImage imageNamed:@"collect_YES_day"];
    
    self.sheet_share_barStyle = UIBarStyleDefault;
    self.sheet_model_barStyle = UIBarStyleDefault;
}

- (void)setNightStyle
{
    self.navigationBar_tintColor = [UIColor colorWithRed:0.99 green:0.62 blue:0.15 alpha:1.00];
//    self.navigationBar_barTintColor = [UIColor colorWithRed:0.11 green:0.11 blue:0.11 alpha:1.00];
    self.navigationBar_barTintColor = nil;
    self.navigationBar_titleColor = [UIColor colorWithRed:0.99 green:0.62 blue:0.15 alpha:1.00];
    
    self.searchBar_tintColor = [UIColor colorWithRed:0.99 green:0.62 blue:0.15 alpha:1.00];
    self.searchBar_barTintColor = [UIColor colorWithRed:0.11 green:0.11 blue:0.11 alpha:1.00];
    self.statusView_backgroundColor = [UIColor blackColor];
    
    UIImage *searchBarImg = [UIImage imageNamed:@"searchBarBg"];
    UIImage *searchBarBg = [self cutImage:searchBarImg];
    self.searchBar_backgroundImage = searchBarBg;
    
//    UIImage *image = [UIImage imageNamed:@"nightBg"];
//    UIImage *backgroundImage = [self cutImage:image];
    self.tabBar_tintColor = [UIColor colorWithRed:0.99 green:0.62 blue:0.15 alpha:1.00];
    self.tabBar_barTintColor = nil;
    self.tabBar_backgroundImage = nil;
    self.tabBar_barStyle = UIBarStyleBlack;
    
    self.searchView_effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];

    self.tbView_separatorColor = [UIColor colorWithWhite:0.3 alpha:1];
    self.tbView_indicatorStyle = UIScrollViewIndicatorStyleWhite;

    self.activity_indicatorStyle = UIActivityIndicatorViewStyleWhite;
    
    self.cell_backgroundColor = [UIColor colorWithRed:0.11 green:0.11 blue:0.11 alpha:1.00];
    self.cell_label_textColor = [UIColor whiteColor];
    self.cell_sumary_textColor = [UIColor grayColor];
    self.cell_textLabel_textColor = [UIColor colorWithRed:1 green:0.8 blue:0 alpha:1];
    self.cell_ingredients_textColor = [UIColor colorWithRed:0.99 green:0.62 blue:0.15 alpha:1.00];
    
    self.customTBView_cell_textColor = [UIColor grayColor];
    
    self.app_backgroundColor = [UIColor colorWithRed:0.09 green:0.09 blue:0.09 alpha:1.00];
    
    self.tabBar_cook_image = [UIImage imageNamed:@"tabBar_cook_image_night"];
    self.tabBar_cook_selectedImage = [UIImage imageNamed:@"tabBar_cook_selectedImage_night"];
    
    self.tabBar_more_image = [UIImage imageNamed:@"tabBar_more_image_night"];
    self.tabBar_cook_selectedImage = [UIImage imageNamed:@"tabBar_cook_selectedImage_night"];
    
    self.shareImage = [UIImage imageNamed:@"shareImage_night"];
    self.collect_NO = [UIImage imageNamed:@"collect_NO_night"];
    self.collect_YES = [UIImage imageNamed:@"collect_YES_night"];
    
    self.sheet_model_barStyle = UIBarStyleBlack;
    self.sheet_share_barStyle = UIBarStyleBlack;
}

#pragma mark 裁剪图片
- (UIImage *)cutImage:(UIImage*)image
{
    CGImageRef imageRef = CGImageCreateWithImageInRect([image CGImage], CGRectMake(0, 0, screenW, tabBarHeight));
    return [UIImage imageWithCGImage:imageRef];
}
@end
