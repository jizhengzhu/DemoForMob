//
//  JZCollectAndShareView.h
//  tf02
//
//  Created by F7686324 on 10/12/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZCollectAndShareView : UIView

@property (nonatomic, strong) UIButton *collectBtn;
@property (nonatomic, strong) UIButton *shareBtn;

@end
