//
//  JZCookRecipe.h
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZCookRecipe : NSObject

@property (nonatomic, copy) NSString *img;
@property (nonatomic, strong) NSArray *method;
@property (nonatomic, copy) NSString *ingredients;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *sumary;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)cookRecipeWithDict:(NSDictionary *)dict;
@end
