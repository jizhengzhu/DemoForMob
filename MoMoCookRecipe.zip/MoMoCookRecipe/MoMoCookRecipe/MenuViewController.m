//
//  MenuViewController.m
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "MenuViewController.h"
#import "Utility.h"
#import "CookViewController.h"
#import "JZCookName.h"
@interface MenuViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tbView;

@end

@implementation MenuViewController

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH) style:UITableViewStyleGrouped];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.backgroundColor = [UIColor clearColor];
    }
    return _tbView;
}

- (void)setMenuArray:(NSArray *)menuArray
{
    _menuArray = menuArray;
    [self.tbView reloadData];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self changeAppBackgroundStyle];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    [self.view addSubview:self.tbView];
}

- (void)changeAppBackgroundStyle
{
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    [self.tbView reloadData];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"MenuViewController-cellID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];

    }
    JZCookName *cookName = [self.menuArray objectAtIndex:indexPath.row];
    cell.textLabel.text = cookName.name;
    cell.textLabel.textColor = [ColorManager manager].cell_textLabel_textColor;
    cell.backgroundColor = [ColorManager manager].cell_backgroundColor;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.menuArray.count;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    CookViewController *cookVC = [[CookViewController alloc] init];
    JZCookName *cookName = [self.menuArray objectAtIndex:indexPath.row];
    cookVC.cookName = cookName;
    [self.navigationController pushViewController:cookVC animated:YES];
}

@end
