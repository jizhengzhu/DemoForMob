//
//  JZTabBarController.h
//  CookRecipe
//
//  Created by F7686324 on 07/12/2016.
//  Copyright © 2016 Jim.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZTabBarController : UITabBarController <UITabBarControllerDelegate>


@end
