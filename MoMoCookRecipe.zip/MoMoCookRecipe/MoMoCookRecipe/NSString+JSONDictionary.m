//
//  NSString+JSONDictionary.m
//  MoMoCookRecipe
//
//  Created by F7686324 on 2016/12/14.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "NSString+JSONDictionary.h"

@implementation NSString (JSONDictionary)

- (NSDictionary *)JSONDictionary
{
    NSError *error = nil;
    NSData *data = [self dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
    return dict;
}

@end
