//
//  JZCookMenu.h
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZCookMenu : NSObject

@property (nonatomic, copy) NSArray *ctgIds;
@property (nonatomic, copy) NSString *ctgTitles;
@property (nonatomic, copy) NSDictionary *recipe;
@property (nonatomic, copy) NSString *menuId;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *thumbnail;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)cookMenuWithDict:(NSDictionary *)dict;
+ (instancetype)cookMenuWithMenuId:(NSString *)menuId
                              name:(NSString *)name
                         thumbnail:(NSString *)thumbnail
                            recipe:(NSString *)recipe;
@end
