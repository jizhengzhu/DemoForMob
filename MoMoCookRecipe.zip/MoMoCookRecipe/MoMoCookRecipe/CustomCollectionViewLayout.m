//
//  CustomCollectionViewLayout.m
//  CookRecipe
//
//  Created by Jim on 2016/12/8.
//  Copyright © 2016年 Jim.com. All rights reserved.
//

#import "CustomCollectionViewLayout.h"

@implementation CustomCollectionViewLayout

- (instancetype)init
{
    self = [super init];
    if (self) {
//        self.scrollDirection = UICollectionViewScrollDirectionVertical;
//        self.itemSize = CGSizeMake(100, 100);

    }
    return self;
}

@end
