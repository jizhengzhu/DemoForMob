//
//  CookDetailViewController.m
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "CookDetailViewController.h"
#import "Utility.h"
#import "NSString+shouhangsuojing.h"
#import "CookDetailFrame.h"
#import "JZCookStep.h"
#import "JZCollectAndShareView.h"
#import "CustomSheet.h"
#import <UMSocialCore/UMSocialCore.h>
#import "JZFmdbTool.h"
#import "NSDictionary+JSONString.h"

@interface CookDetailViewController () <UITableViewDelegate, UITableViewDataSource, CustomCollectionViewDelegate>

@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableArray *frameArray;
@property (nonatomic, strong) NSMutableArray *cookStepArray;
@property (nonatomic, strong) UILabel *lblTitle;
@property (nonatomic, strong) UILabel *lblSumary;
@property (nonatomic, strong) UIImageView *imgView;
@property (nonatomic, strong) UILabel *lblIngredients;
@property (nonatomic, strong) JZCollectAndShareView *collectAndShareView;

@end

@implementation CookDetailViewController
static CGFloat margin = 10;

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH)];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tbView.backgroundColor = [UIColor clearColor];
        
    }
    return _tbView;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (NSMutableArray *)frameArray
{
    if (!_frameArray) {
        _frameArray = [NSMutableArray array];
    }
    return _frameArray;
}

- (NSMutableArray *)cookStepArray
{
    if (!_cookStepArray) {
        _cookStepArray = [NSMutableArray array];
    }
    return _cookStepArray;
}

- (UILabel *)lblTitle
{
    if (!_lblTitle) {
        _lblTitle = [[UILabel alloc] init];
        _lblTitle.numberOfLines = 0;
        _lblTitle.lineBreakMode = NSLineBreakByCharWrapping;
        _lblTitle.font = [UIFont systemFontOfSize:20];
        _lblTitle.textAlignment = NSTextAlignmentCenter;
    }
    return _lblTitle;
}

- (UILabel *)lblSumary
{
    if (!_lblSumary) {
        _lblSumary = [[UILabel alloc] init];
        _lblSumary.numberOfLines = 0;
    }
    return _lblSumary;
}

- (UIImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[UIImageView alloc] init];
        
    }
    return _imgView;
}

- (UILabel *)lblIngredients
{
    if (!_lblIngredients) {
        _lblIngredients = [[UILabel alloc] init];
        _lblIngredients.numberOfLines = 0;
        
    }
    return _lblIngredients;
}

- (JZCollectAndShareView *)collectAndShareView
{
    if (!_collectAndShareView) {
        _collectAndShareView = [[JZCollectAndShareView alloc] initWithFrame:CGRectMake(0, 0, 60, 44)];
        [_collectAndShareView.shareBtn addTarget:self action:@selector(shareAction:) forControlEvents: UIControlEventTouchUpInside];
        [_collectAndShareView.collectBtn addTarget:self action:@selector(collectAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _collectAndShareView;
}

- (void)setCookMenu:(JZCookMenu *)cookMenu
{
    _cookMenu = cookMenu;
    self.title = cookMenu.name;
    NSLog(@"cookMenu.menuId = %@", cookMenu.menuId);

    NSString *value = [self distinguishCollectionStatusByCookMenu:cookMenu];
    UIImage *collectImage;
    if ([value isEqualToString:@"已收藏"]) {
        collectImage = [ColorManager manager].collect_YES;
    } else if ([value isEqualToString:@"未收藏"]) {
        collectImage = [ColorManager manager].collect_NO;
    }
    [self.collectAndShareView.collectBtn setImage:collectImage forState:UIControlStateNormal];
    UIBarButtonItem *shoucangItem = [[UIBarButtonItem alloc] initWithCustomView: self.collectAndShareView];
    self.navigationItem.rightBarButtonItem = shoucangItem;
}

#pragma mark 鉴别是否收藏
- (NSString *)distinguishCollectionStatusByCookMenu:(JZCookMenu *)cookMenu
{
    NSString *querySql = [NSString stringWithFormat:@"SELECT * FROM jz_models WHERE menuId = '%@'", cookMenu.menuId];
    NSArray *arr = [JZFmdbTool queryData:querySql];

    NSString *value = @"未收藏";
    if (arr.count) {
        value = @"已收藏";
    }

    return value;
}

- (void)setCookRecipe:(JZCookRecipe *)cookRecipe
{
    _cookRecipe = cookRecipe;
    CookDetailFrame *cookDetailFrame = [CookDetailFrame cookDetailFrameWithCookRecipe:cookRecipe];
    [self.dataArray removeAllObjects];
    [self.frameArray removeAllObjects];
    [self.cookStepArray removeAllObjects];
    
    for (int i = 0; i < cookRecipe.method.count * 2 + 4; i++) {
        CGRect rect = CGRectFromString([cookDetailFrame.frameArray objectAtIndex:i]);
        UIView *view = [[UIView alloc] init];
        view.frame = rect;
        [self.dataArray addObject:view];
        [self.frameArray addObject:NSStringFromCGRect(rect)];
    }

    self.lblTitle.text = cookRecipe.title;
    self.lblSumary.attributedText = [cookRecipe.sumary shouhangsuojing:[UIFont systemFontOfSize:17]];
    
    [self.imgView sd_setImageWithURL:[NSURL URLWithString:cookRecipe.img] placeholderImage:[UIImage imageNamed:@""] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        CGRect rect = CGRectMake(screenW * 0.05, margin, screenW * 0.9, screenW * 0.9 * image.size.height / image.size.width);
        [self.frameArray removeObjectAtIndex:2];
        [self.frameArray insertObject:NSStringFromCGRect(rect) atIndex:2];
        [self.tbView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:2 inSection:0]] withRowAnimation:UITableViewRowAnimationAutomatic];
    }];
    self.lblIngredients.text = cookRecipe.ingredients;
    for (int i = 0; i < self.cookRecipe.method.count; i++) {
        NSDictionary *dict = [self.cookRecipe.method objectAtIndex:i];
        JZCookStep *cookStep = [JZCookStep cookStepWithDict:dict];
        UILabel *lbl = [[UILabel alloc] init];
        lbl.numberOfLines = 0;
        lbl.text = cookStep.step;
        [self.cookStepArray addObject:lbl];
        UIImageView *imgView = [[UIImageView alloc] init];
        [imgView sd_setImageWithURL:[NSURL URLWithString:cookStep.img] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            CGRect rect = CGRectMake(screenW * 0.05, margin, screenW * 0.9, screenW * 0.9 *image.size.height / image.size.width);
            [self.frameArray removeObjectAtIndex:i * 2 + 5];
            [self.frameArray insertObject:NSStringFromCGRect(rect) atIndex:i * 2 + 5];
            [self.tbView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:i * 2 + 5 inSection:0]] withRowAnimation:UITableViewRowAnimationAutomatic];

        }];
        [self.cookStepArray addObject:imgView];
    }
    [self.tbView reloadData];
    NSLog(@"cookRecipe.ingredients = %@", cookRecipe.ingredients);
    NSLog(@"cookRecipe.method.count = %lu", (unsigned long)cookRecipe.method.count);
    for (NSDictionary *dict in cookRecipe.method) {
        NSLog(@"dict = %@", [dict JSONString]);
    }
    NSLog(@"cookRecipe.img = %@", cookRecipe.img);
    NSLog(@"cookRecipe.sumary = %@", cookRecipe.sumary);
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [LCProgressHUD hide];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self changeAppBackgroundStyle];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    [self.view addSubview:self.tbView];

    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.collectAndShareView];
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
    
}

- (void)changeAppBackgroundStyle
{
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    [self.tbView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    UIView *view = [self.dataArray objectAtIndex:indexPath.row];
    NSString *rectString = [self.frameArray objectAtIndex:indexPath.row];
    view.frame = CGRectFromString(rectString);
    if (indexPath.row == 0) {
        self.lblTitle.frame = view.bounds;
        self.lblTitle.textColor = [ColorManager manager].cell_label_textColor;
        [view addSubview:self.lblTitle];
    } else if (indexPath.row == 1) {
        self.lblSumary.frame = view.bounds;
        self.lblSumary.textColor= [ColorManager manager].cell_sumary_textColor;
        [view addSubview:self.lblSumary];
    } else if (indexPath.row == 2) {
        self.imgView.frame = view.bounds;
        [view addSubview:self.imgView];
    } else if (indexPath.row == 3) {
        self.lblIngredients.frame = view.bounds;
        self.lblIngredients.textColor = [ColorManager manager].cell_ingredients_textColor;
        [view addSubview:self.lblIngredients];
    } else {
        for (int i = 0; i < self.cookRecipe.method.count; i++) {
            if (indexPath.row == i * 2 + 4) {
                UILabel *lbl = [self.cookStepArray objectAtIndex:i * 2];
                lbl.frame = view.bounds;
                lbl.textColor = [ColorManager manager].cell_label_textColor;
                [view addSubview:lbl];
            } else if (indexPath.row == i * 2 + 5) {
                UIImageView *imgView = [self.cookStepArray objectAtIndex:i * 2 + 1];
                imgView.frame = view.bounds;
                [view addSubview:imgView];
            }
        }
    }
    
    [cell addSubview:view];
    cell.backgroundColor = [ColorManager manager].cell_backgroundColor;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *rectString = [self.frameArray objectAtIndex:indexPath.row];
    CGRect rect = CGRectFromString(rectString);
    if (rect.size.height) {
        return rect.size.height + margin * 2;
    } else {
        return 0;
    }
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
    return NO;
}

#pragma mark 分享按钮
- (void)shareAction:(UIButton *)btn
{
    [CustomSheet shareSheet].collectView.delegate = self;
    [[CustomSheet shareSheet] showAppShare];

}

#pragma mark 收藏按钮
- (void)collectAction:(UIButton *)btn
{
    NSString *value = [self distinguishCollectionStatusByCookMenu:self.cookMenu];
    [self distinguishCollecionOperationByValue:value];
}

#pragma mark 根据收藏状态执行相应动作
- (void)distinguishCollecionOperationByValue:(NSString *)value
{
    UIImage *collectImage;
    if ([value isEqualToString:@"未收藏"]) {
        JZModel *model = [JZModel modelWithThumbnail:self.cookMenu.thumbnail
                                                name:self.cookMenu.name
                                              sumary:self.cookRecipe.sumary
                                              menuId:self.cookMenu.menuId
                                              recipe:[self.cookMenu.recipe JSONString]];
        [JZFmdbTool insertModel:model];
        collectImage = [ColorManager manager].collect_YES;
        [LCProgressHUD showInfoMsg:@"收藏成功"];
    } else if ([value isEqualToString:@"已收藏"]) {
        NSString *deleteSql = [NSString stringWithFormat:@"DELETE FROM jz_models WHERE menuId = '%@'", self.cookMenu.menuId];
        [JZFmdbTool deleteData:deleteSql];
        collectImage = [ColorManager manager].collect_NO;
        [LCProgressHUD showInfoMsg:@"取消收藏成功"];
    }

    [self.collectAndShareView.collectBtn setImage:collectImage forState:UIControlStateNormal];
    UIBarButtonItem *shoucangItem = [[UIBarButtonItem alloc] initWithCustomView:self.collectAndShareView];
    self.navigationItem.rightBarButtonItem = shoucangItem;
}

#pragma mark CustomCollectionViewDelegate Methods
-  (void)customCollectionView:(CustomCollectionView *)customCollectionVeiw didSelectItemAtIndex:(NSInteger)index;
{
    [[CustomSheet shareSheet] hide];
    switch (index) {
        case 0:
            [self shareWebPageToPlatformType:UMSocialPlatformType_WechatTimeLine];
            break;
        case 1:
            [self shareWebPageToPlatformType:UMSocialPlatformType_WechatSession];

            break;
        case 2:
            [self shareWebPageToPlatformType:UMSocialPlatformType_Qzone];

            break;
        case 3:
            [self shareWebPageToPlatformType:UMSocialPlatformType_QQ];

            break;
        case 4:
            [self shareWebPageToPlatformType:UMSocialPlatformType_Sina];

            break;
        case 5:
            [self showIOSShareSheet];

            break;
        default:
            break;
    }
}

#pragma mark 分享网页
- (void)shareWebPageToPlatformType:(UMSocialPlatformType)platformType
{
    //创建分享消息对象
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];

    UIImageView *imgView = [[UIImageView alloc] init];

    [imgView sd_setImageWithURL:[NSURL URLWithString:self.cookMenu.thumbnail] placeholderImage:[UIImage imageNamed:@"replaceImage"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        if (error) {
            NSLog(@"error = %@", error.userInfo);
            image = [UIImage imageNamed:@"replaceImage"];
        }
        //创建网页内容对象
        UMShareWebpageObject *shareObject = [UMShareWebpageObject shareObjectWithTitle:self.cookMenu.name descr:self.cookRecipe.sumary thumImage:image];
        //设置网页地址
        shareObject.webpageUrl = @"https://www.zhujizheng.com";

        //分享消息对象设置分享内容对象
        messageObject.shareObject = shareObject;

        //调用分享接口
        [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:self completion:^(id data, NSError *error) {
            if (error) {
                NSLog(@"************Share fail with error %@*********",error);
            }else{
                NSLog(@"response data is %@",data);
            }
        }];
    }];


}

#pragma mark 弹出iOS系统自带的分享面板
- (void)showIOSShareSheet
{
    NSLog(@"%s", __FUNCTION__);

    NSArray *activityItems = @[@"title", @"content", [UIImage imageNamed:@"qq"], [NSURL URLWithString:@"https://www.zhujizheng.com"]];
    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:activityItems applicationActivities:nil];
    activityVC.excludedActivityTypes = @[UIActivityTypePostToFacebook,
                                         UIActivityTypePostToTwitter,
                                         UIActivityTypePrint,
                                         UIActivityTypeAssignToContact,
                                         UIActivityTypeSaveToCameraRoll,
                                         UIActivityTypeAddToReadingList,
                                         UIActivityTypePostToFlickr,
                                         UIActivityTypePostToVimeo,
                                         UIActivityTypePostToTencentWeibo,
                                         UIActivityTypeAirDrop];
    [self presentViewController:activityVC animated:YES completion:nil];
    activityVC.completionWithItemsHandler = ^(UIActivityType activityType, BOOL completed, NSArray * returnedItems, NSError * activityError) {
        if (activityType == UIActivityTypePostToWeibo) {
            if (completed) {
                NSLog(@"微博分享已完成");

            }
        }
    };
}

- (NSArray<id<UIPreviewActionItem>> *)previewActionItems {
// setup a list of preview actions

    NSString *value = [self distinguishCollectionStatusByCookMenu:self.cookMenu];
    NSString *text = @"收藏";
    if ([value isEqualToString:@"已收藏"]) {
        text = @"取消收藏";
    } else if ([value isEqualToString:@"未收藏"]) {
        text = @"加入我的收藏";
    }
    UIPreviewAction *action1 = [UIPreviewAction actionWithTitle:text style:UIPreviewActionStyleDefault handler:^(UIPreviewAction * _Nonnull action, UIViewController * _Nonnull previewViewController) {
        [self distinguishCollecionOperationByValue:value];
        [[NSNotificationCenter defaultCenter] postNotificationName:updateCollectionNotification object:nil];
    }];


    NSArray *actions = @[action1];

    return actions;

// and return them (return the array of actions instead to see all items ungrouped)
}
@end
