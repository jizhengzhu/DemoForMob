//
//  JZCookCategory.m
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZCookCategory.h"

@implementation JZCookCategory

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)cookCategoryWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

@end
