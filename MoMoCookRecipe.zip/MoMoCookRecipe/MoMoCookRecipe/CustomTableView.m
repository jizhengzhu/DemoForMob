//
//  CustomTableView.m
//  MoMoCookRecipe
//
//  Created by F7686324 on 2016/12/9.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "CustomTableView.h"
#import "Utility.h"
@implementation CustomTableView

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:self.bounds style:UITableViewStyleGrouped];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.bounces = NO;
        _tbView.separatorInset = UIEdgeInsetsZero;
        _tbView.backgroundColor = [UIColor clearColor];
    }
    return _tbView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.tbView];
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"CustomTableView-Cellid";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
        cell.textLabel.textAlignment = NSTextAlignmentCenter;

    }
    cell.backgroundColor = [ColorManager manager].cell_backgroundColor;
    cell.textLabel.textColor = [ColorManager manager].customTBView_cell_textColor;
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            
            cell.textLabel.text = @"夜晚";
        } else if (indexPath.row == 1) {
            cell.textLabel.text = @"白天";
        }
    } else if (indexPath.section == 1) {
        cell.textLabel.text = @"取消";
    }
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 2;
    } else if (section == 1) {
        return 1;
    } else {
        return 0;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return 0.1f;
            break;
        case 1:
            return 10;
            break;
        default:
            return 0;
            break;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1f;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 1) {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 10)];
        headerView.backgroundColor = [ColorManager manager].app_backgroundColor;

        return headerView;
    } else {
        return 0;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (self.delegate && [self.delegate respondsToSelector:@selector(customTableView:didSelectRowAtIndexPath:)]) {
        [self.delegate customTableView:self didSelectRowAtIndexPath:indexPath];
    }
}

@end
