//
//  CustomCollectionView.h
//  CookRecipe
//
//  Created by Jim on 2016/12/8.
//  Copyright © 2016年 Jim.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomCollectionViewLayout.h"
@class CustomCollectionView;
@protocol CustomCollectionViewDelegate <NSObject>

@required
- (void)customCollectionView:(CustomCollectionView *)customCollectionVeiw didSelectItemAtIndex:(NSInteger)index;

@end

@interface CustomCollectionView : UIView <UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) CustomCollectionViewLayout *customLayout;
@property (nonatomic, strong) NSArray *itemArray;
@property (nonatomic, weak) id <CustomCollectionViewDelegate> delegate;

@end
