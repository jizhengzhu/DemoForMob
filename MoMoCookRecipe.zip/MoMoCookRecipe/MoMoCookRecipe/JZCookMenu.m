//
//  JZCookMenu.m
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZCookMenu.h"
#import "NSString+JSONDictionary.h"
@implementation JZCookMenu

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        if ([dict[@"ctgIds"] isKindOfClass:[NSArray class]]) {
            self.ctgIds = dict[@"ctgIds"];
        } else {
            self.ctgIds = [NSArray array];
        }

        if (dict[@"ctgTitles"]) {
            self.ctgTitles = dict[@"ctgTitles"];
        } else {
            self.ctgTitles = @"";
        }

        if ([dict[@"recipe"] isKindOfClass:[NSDictionary class]]) {
            self.recipe = dict[@"recipe"];
        } else {
            self.recipe = [NSDictionary dictionary];
        }

        if (dict[@"menuId"]) {
            self.menuId = dict[@"menuId"];
        } else {
            self.menuId = @"";
        }

        if (dict[@"name"]) {
            self.name = dict[@"name"];
        } else {
            self.name = @"";
        }

        if (dict[@"thumbnail"]) {
            self.thumbnail = [dict[@"thumbnail"] stringByReplacingOccurrencesOfString:@"http" withString:@"https"];
        } else {
            self.thumbnail = @"";
        }
    }
    return self;
}

+ (instancetype)cookMenuWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

+ (instancetype)cookMenuWithMenuId:(NSString *)menuId
                              name:(NSString *)name
                         thumbnail:(NSString *)thumbnail
                            recipe:(NSString *)recipe
{
    JZCookMenu *cookMenu = [[JZCookMenu alloc] init];
    cookMenu.menuId = menuId;
    cookMenu.name = name;
    cookMenu.thumbnail = thumbnail;
    cookMenu.recipe = [recipe JSONDictionary];
    cookMenu.ctgIds = [NSArray array];
    cookMenu.ctgTitles = @"";
    return cookMenu;
}

//- (NSUInteger)hash
//{
//    return [self.menuId hash];
//}

@end
