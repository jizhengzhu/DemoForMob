//
//  JZCookStep.h
//  小助手
//
//  Created by Jim on 2016/12/6.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZCookStep : NSObject

@property (nonatomic, copy) NSString *img;
@property (nonatomic, copy) NSString *step;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)cookStepWithDict:(NSDictionary *)dict;
@end
