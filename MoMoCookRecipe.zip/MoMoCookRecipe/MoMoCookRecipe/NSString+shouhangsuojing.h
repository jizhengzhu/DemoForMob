//
//  NSString+shouhangsuojing.h
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (shouhangsuojing)

- (NSAttributedString *)shouhangsuojing:(UIFont *)font;

@end
