//
//  MainViewController.m
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "MainViewController.h"
#import "Utility.h"
#import "JZCookName.h"
#import "JZCookCategory.h"
#import "MenuViewController.h"
#import "MJRefresh.h"
#import "JZTabBarController.h"
#import "JZCookMenu.h"
#import "JZCookRecipe.h"
#import "CookDetailViewController.h"
#import "SearchView.h"

@interface MainViewController () <UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, SearchViewDelegate, UIGestureRecognizerDelegate>
{
    CGFloat mjCount;
    BOOL isSearch;
}
@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, strong) NSMutableArray *keyArray;
@property (nonatomic, strong) NSMutableDictionary *dataDict;
@property (nonatomic, strong) UISearchBar *searchBar;

@property (nonatomic, strong) UIView *statusBarView;
@property (nonatomic, strong) NSMutableArray *cookMenuArray;
@property (nonatomic, strong) NSMutableArray *cookRecipeArray;
@property (nonatomic, strong) SearchView *searchView;

@property (nonatomic, strong) UILabel *tips;

@property (nonatomic, strong) NSTimer *timer;
@end

@implementation MainViewController

- (UISearchBar *)searchBar
{
    if (!_searchBar) {
        _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, screenW, tabBarHeight)];
        _searchBar.delegate = self;
        _searchBar.placeholder = @"菜名，食材";
        _searchBar.searchBarStyle = UISearchBarStyleDefault;
    }
    return _searchBar;
}

- (NSMutableArray *)keyArray
{
    if (!_keyArray) {
        _keyArray = [NSMutableArray array];
    }
    return _keyArray;
}

- (NSMutableDictionary *)dataDict
{
    if (!_dataDict) {
        _dataDict = [NSMutableDictionary dictionary];
    }
    return _dataDict;
}

- (NSMutableArray *)cookMenuArray
{
    if (!_cookMenuArray) {
        _cookMenuArray = [NSMutableArray array];
    }
    return _cookMenuArray;
}

- (NSMutableArray *)cookRecipeArray
{
    if (!_cookRecipeArray) {
        _cookRecipeArray = [NSMutableArray array];
    }
    return _cookRecipeArray;
}


- (UIView *)statusBarView
{
    if (!_statusBarView) {
        _statusBarView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 20)];
    }
    return _statusBarView;
}

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH - tabBarHeight + statusHeight)];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.separatorInset = UIEdgeInsetsMake(0, screenW, 0, 0);
        _tbView.backgroundColor = [UIColor clearColor];
    }
    return _tbView;
}

- (UILabel *)tips
{
    if (!_tips) {
        NSString *str = @"正在加载全部菜谱...";
        CGSize size = [str boundingRectWithSize:CGSizeMake(screenW, 17)
                                         options:NSStringDrawingUsesFontLeading
                                      attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]}
                                         context:nil].size;

        _tips = [[UILabel alloc] initWithFrame:CGRectMake((screenW - size.width) / 2, tabBarHeight, size.width, screenH - statusHeight - naviHeight - tabBarHeight * 2)];
        _tips.textColor = [UIColor grayColor];
        _tips.font = [UIFont systemFontOfSize:17];
        
    }
    return _tips;
}

- (SearchView *)searchView
{
    if (!_searchView) {
        _searchView = [[SearchView alloc] initWithFrame:CGRectMake(0, tabBarHeight, screenW, screenH - naviHeight - statusHeight)];
        _searchView.delegate = self;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction)];
        tap.delegate = self;
        [_searchView addGestureRecognizer:tap];
    }
    return _searchView;
}

- (NSTimer *)timer
{
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(repeatAction) userInfo:nil repeats:YES];
    }
    return _timer;
}

- (void)repeatAction
{
    NSString *str = @"正在加载全部菜谱...";
    CGSize size = [str boundingRectWithSize:CGSizeMake(screenW, 17)
                                    options:NSStringDrawingUsesFontLeading
                                 attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]}
                                    context:nil].size;
    self.tips.frame = CGRectMake((screenW - size.width) / 2, tabBarHeight, size.width, screenH - statusHeight - naviHeight - tabBarHeight * 2);
    self.tips.text = @"正在加载全部菜谱";
    [self performSelector:@selector(firstStep) withObject:nil afterDelay:0.25];
    [self performSelector:@selector(secondStep) withObject:nil afterDelay:0.5];
    [self performSelector:@selector(thirdStep) withObject:nil afterDelay:0.75];
}

#pragma mark 点击SearchView时执行的操作
- (void)tapAction
{
    [self.searchBar resignFirstResponder];
    [self changeSearchBarCancelBtnTitleColor:self.searchBar];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if (isSearch) {
        [self.navigationController setNavigationBarHidden:YES animated:YES];
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    }
    [self changeAppBackgroundStyle];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [LCProgressHUD hide];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    isSearch = NO;
    [self.tbView addSubview:self.tips];
    [self.timer fire];
    [self sendRequest];
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    [self.view addSubview:self.tbView];
    self.tbView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
        [self.timer fire];
        [LCProgressHUD showLoading:@"加载中"];
        [self sendRequest];
    }];
    NSLog(@"img.size = %@", NSStringFromCGSize(self.tabBarController.tabBarItem.selectedImage.size));
}

- (void)firstStep
{
    self.tips.text = @"正在加载全部菜谱.";
}

- (void)secondStep
{
    self.tips.text = @"正在加载全部菜谱..";

}

- (void)thirdStep
{
    self.tips.text = @"正在加载全部菜谱...";

}

- (void)setTipsText
{
    self.tips.text = @"网络有点卡...";
}

- (void)changeAppBackgroundStyle
{
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    self.tabBarController.tabBar.barTintColor = [ColorManager manager].tabBar_barTintColor;
    self.tabBarController.tabBar.tintColor = [ColorManager manager].tabBar_tintColor;
    self.tabBarController.tabBar.backgroundImage = [ColorManager manager].tabBar_backgroundImage;
    self.tabBarController.tabBar.barStyle = [ColorManager manager].tabBar_barStyle;
    self.tabBarController.tabBarItem.image = [ColorManager manager].tabBar_cook_image;
    self.tabBarController.tabBarItem.selectedImage = [ColorManager manager].tabBar_cook_selectedImage;
    [self.tbView.mj_header prepare];
    [self.tbView reloadData];
}
#pragma mark 获取全部菜谱
- (void)sendRequest
{
    [MobAPI sendRequest:[MOBACookRequest categoryRequest] onResult:^(MOBAResponse *response) {
        [self.tbView.mj_header endRefreshing];

        if (response.error) {
            if ([response.error.userInfo objectForKey:@"error_message"]) {
                [LCProgressHUD showInfoMsg:[response.error.userInfo objectForKey:@"error_message"]];
                
            } else {
                [LCProgressHUD showInfoMsg:@"网络有点卡..."];
                NSString *str = @"网络有点卡...";
                CGSize size = [str boundingRectWithSize:CGSizeMake(screenW, 17) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} context:nil].size;
                self.tips.frame = CGRectMake((screenW - size.width) / 2, tabBarHeight, size.width, screenH - statusHeight - naviHeight - tabBarHeight * 2);
                [self.timer invalidate];
                _timer = nil;
                [self performSelector:@selector(setTipsText) withObject:nil afterDelay:1];
            }
        } else {
            [LCProgressHUD hide];
            NSDictionary *cookCategoryAllDict = response.responder[@"result"];
            NSLog(@"cookCategoryAllDict = %@", [cookCategoryAllDict JSONString]);
            if ([cookCategoryAllDict isKindOfClass:[NSDictionary class]]) {
                JZCookCategory *cookCategoryAll = [JZCookCategory cookCategoryWithDict:cookCategoryAllDict];
                
                [self.keyArray removeAllObjects];
                
                if (cookCategoryAll.childs.count) {

                    for (NSDictionary *cookCategoryDict in cookCategoryAll.childs) {
                        
                        JZCookCategory *cookCategory = [JZCookCategory cookCategoryWithDict:cookCategoryDict];
                        
                        JZCookName *cookName = [JZCookName cookNameWithDict:cookCategory.categoryInfo];
                        
                        [self.keyArray addObject:cookName.name];
                        
                        NSMutableArray *array = [NSMutableArray array];
                        
                        
                        for (NSDictionary *cookNameDict in cookCategory.childs) {
                            JZCookName *cookName = [JZCookName cookNameWithDict:[cookNameDict valueForKey:@"categoryInfo"]];
                            [array addObject:cookName];
                        }
                        
                        [self.dataDict setValue:array forKey:cookName.name];
                        
                    }
                    
                    [self.tbView reloadData];
                    [self.tips removeFromSuperview];
                } else {
                    self.tips.text = @"暂无菜谱~";
                }
            }
        }
    }];
}

#pragma mark tableView delegate
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"MainViewController-CellID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
    }
    cell.textLabel.text = [self.keyArray objectAtIndex:indexPath.row];
    cell.textLabel.textColor = [ColorManager manager].cell_textLabel_textColor;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.backgroundColor = [ColorManager manager].cell_backgroundColor;
    cell.separatorInset = UIEdgeInsetsMake(0, 15, 0, 0);
    return cell;

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.keyArray.count;

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    MenuViewController *menuVC = [[MenuViewController alloc] init];
    NSString *key = [self.keyArray objectAtIndex:indexPath.row];
    menuVC.title = key;
    menuVC.menuArray = [self.dataDict valueForKey:key];

    [self.navigationController pushViewController:menuVC animated:YES];

}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    self.searchBar.backgroundImage = [ColorManager manager].searchBar_backgroundImage;
    self.searchBar.barTintColor = [ColorManager manager].searchBar_barTintColor;
    self.searchBar.tintColor = [ColorManager manager].searchBar_tintColor;
    return self.searchBar;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return tabBarHeight;
}

#pragma mark searchBar delegate
#pragma mark 开始编辑
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    NSLog(@"%s", __FUNCTION__);
    NSLog(@"Class = %@", searchBar.subviews);
    if ([[NSString valueByKey:keyAppBackgroundStyle] isEqualToString:@"白天"]) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;

    }
    [searchBar setShowsCancelButton:YES animated:YES];
    [self changeSearchBarCancelBtnTitleColor:searchBar];

    
    self.statusBarView.backgroundColor = [ColorManager manager].statusView_backgroundColor;
    [self.view addSubview:self.statusBarView];

    [self clearSearchViewData];

    self.searchView.tbView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self sendRequestWithPage:mjCount ctgId:nil name:searchBar.text];
        mjCount++;
    }];
    [self.searchView.tbView.mj_footer setHidden:YES];
    self.searchView.visualEffectView.effect = [ColorManager manager].searchView_effect;
    self.searchView.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.searchView.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    [self.tbView addSubview:self.searchView];
    
    [self.tbView.mj_header setHidden:YES];
    self.tbView.bounces = NO;
    self.tbView.frame = [UIScreen mainScreen].bounds;
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    [self.tabBarController.tabBar setHidden:YES];

    isSearch = YES;

}

#pragma mark 已结束编辑
- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    NSLog(@"%s", __FUNCTION__);

    [searchBar resignFirstResponder];
    [self changeSearchBarCancelBtnTitleColor:searchBar];
    NSLog(@"%s", __FUNCTION__);

}

#pragma mark 点击取消按钮
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    NSLog(@"%s", __FUNCTION__);

    [LCProgressHUD hide];
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    searchBar.backgroundImage = [ColorManager manager].searchBar_backgroundImage;
    [searchBar setShowsCancelButton:NO animated:YES];
    [self.statusBarView removeFromSuperview];
    [self.searchView removeFromSuperview];

    [self.tbView.mj_header setHidden:NO];
    self.tbView.bounces = YES;
    self.tbView.frame = CGRectMake(0, 0, screenW, screenH - naviHeight - statusHeight);
    
    [searchBar resignFirstResponder];
    [self changeSearchBarCancelBtnTitleColor:searchBar];
    searchBar.text = @"";
    
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [self.tabBarController.tabBar setHidden:NO];
    isSearch = NO;
}

#pragma mark 编辑中
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSLog(@"%s", __FUNCTION__);

    mjCount = 2;
    [self clearSearchViewData];
    if (searchBar.text.length) {
        [self sendRequestWithPage:1 ctgId:nil name:searchText];
    }
    if (!searchBar.text.length) {
        [self.searchView.tbView.mj_footer setHidden:YES];
    }
}

#pragma mark 点击search按钮
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    NSLog(@"%s", __FUNCTION__);

    NSLog(@"clickSearch");
    mjCount = 2;
    if (searchBar.text.length) {
        [LCProgressHUD showLoading:@"加载中"];
        [self sendRequestWithPage:1 ctgId:nil name:searchBar.text];
    }
    [searchBar resignFirstResponder];
    [self changeSearchBarCancelBtnTitleColor:searchBar];
}

#pragma mark 按输入的字符串查询菜谱
- (void)sendRequestWithPage:(NSInteger)page ctgId:(NSString *)ctgId name:(NSString *)name
{
    [LCProgressHUD showLoading:@"加载中"];

    [MobAPI sendRequest:[MOBACookRequest searchMenuRequestByCid:ctgId
                                                           name:name
                                                           page:page
                                                           size:20] onResult:^(MOBAResponse *response) {
        [self.searchView.tbView.mj_footer endRefreshing];
        if (response.error) {
            if ([response.error.userInfo objectForKey:@"error_message"]) {
                [LCProgressHUD showInfoMsg:[response.error.userInfo objectForKey:@"error_message"]];
            } else {
                [LCProgressHUD showInfoMsg:@"网络有点卡..."];

            }
            [self clearSearchViewData];

        } else {
            [LCProgressHUD hide];
            NSLog(@"response success = %@", [response.responder JSONString]);

            NSArray *list = [response.responder objectForKey:@"list"];
            if ([list isKindOfClass:[NSArray class]]) {
                if (list.count) {
                    for (NSDictionary *dict in list) {
                        JZCookMenu *cookMenu = [JZCookMenu cookMenuWithDict:dict];
                        JZCookRecipe *cookRecipe = [JZCookRecipe cookRecipeWithDict:cookMenu.recipe];
                        [self.cookMenuArray addObject:cookMenu];
                        [self.cookRecipeArray addObject:cookRecipe];
                    }
                    self.searchView.cookMenuArray = self.cookMenuArray;
                    self.searchView.cookRecipeArray = self.cookRecipeArray;
                    [self.searchView.tbView reloadData];
                    [self.searchView.tbView.mj_footer setHidden:NO];
                } else {
                    [self.searchView.tbView.mj_footer endRefreshingWithNoMoreData];
                }
            } else {
                [self.searchView.tbView.mj_footer endRefreshingWithNoMoreData];
            }
            
            if (!self.searchBar.text.length) {
                [self clearSearchViewData];
            }

        }
    }];
}

#pragma mark 清除SearchView的数据
- (void)clearSearchViewData
{
    [self.cookMenuArray removeAllObjects];
    [self.cookRecipeArray removeAllObjects];
    self.searchView.cookRecipeArray = self.cookRecipeArray;
    self.searchView.cookMenuArray = self.cookMenuArray;
    [self.searchView.tbView reloadData];
    [self.searchView.tbView.mj_footer setHidden:YES];
}

#pragma mark searchView delegate
- (void)searchView:(SearchView *)searchView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.searchBar resignFirstResponder];
    [self changeSearchBarCancelBtnTitleColor:self.searchBar];
    CookDetailViewController *cookDetailVC = [[CookDetailViewController alloc] init];

    JZCookRecipe *cookRecipe = self.cookRecipeArray[indexPath.row];
    cookDetailVC.cookRecipe = cookRecipe;

    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    cookDetailVC.cookMenu = cookMenu;

    [self.navigationController pushViewController:cookDetailVC animated:YES];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
}

#pragma mark-手势代理，解决和tableview点击发生的冲突
-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if (!self.searchBar.isFirstResponder && [NSStringFromClass([touch.view class]) isEqualToString:@"UITableViewCellContentView"]) {//判断如果点击的是tableView的cell，就把手势给关闭了
        return NO;//关闭手势
    }//否则手势存在
    return YES;
}

#pragma mark - 遍历改变搜索框 取消按钮的文字颜色

- (void)changeSearchBarCancelBtnTitleColor:(UIView *)view {
    NSLog(@"%s", __FUNCTION__);
    if (view) {

        if ([view isKindOfClass:[UIButton class]]) {

            UIButton *getBtn = (UIButton *)view;
            
            [getBtn setEnabled:YES];//设置可用

            [getBtn setUserInteractionEnabled:YES];
            
            //设置取消按钮字体的颜色
            [getBtn setTitleColor:[ColorManager manager].searchBar_tintColor forState:UIControlStateReserved];
            [getBtn setTitleColor:[ColorManager manager].searchBar_tintColor forState:UIControlStateDisabled];
            
            [getBtn setTitleColor:[ColorManager manager].searchBar_tintColor forState:UIControlStateNormal];//这条才是有效的
            
            [getBtn setTitleColor:[ColorManager manager].searchBar_tintColor forState:UIControlStateHighlighted];
            [getBtn setTitleColor:[ColorManager manager].searchBar_tintColor forState:UIControlStateSelected];
            [getBtn setTitleColor:[ColorManager manager].searchBar_tintColor forState:UIControlStateFocused];
            [getBtn setTitleColor:[ColorManager manager].searchBar_tintColor forState:UIControlStateApplication];

            return;
            
        } else {
            
            for (UIView *subView in view.subviews) {
                
                [self changeSearchBarCancelBtnTitleColor:subView];
                
            }
            
        }
        
    } else {
        
        return;
        
    }
    
}

@end
