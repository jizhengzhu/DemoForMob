//
//  CookTableViewCell.h
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CookTableViewCell : UITableViewCell

@property (nonatomic, strong) UIImageView *imgView;
@property (nonatomic, strong) UILabel *name;
@property (nonatomic, strong) UILabel *sumary;

+ (CookTableViewCell *)cellWithTableView:(UITableView *)tableView;

@end
