//
//  CustomSheet.h
//  CookRecipe
//
//  Created by Jim on 2016/12/8.
//  Copyright © 2016年 Jim.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomCollectionView.h"
#import "CustomTableView.h"

@interface CustomSheet : UIView

+ (CustomSheet *)shareSheet;
@property (nonatomic, strong) CustomCollectionView *collectView;
@property (nonatomic, strong) CustomTableView *tableView;

- (void)showAppShare;
- (void)showBackgroundStyleSheet;

- (void)hide;


@end
