//
//  MoreViewController.m
//  MoMoCookRecipe
//
//  Created by F7686324 on 2016/12/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "MoreViewController.h"
#import "SettingViewController.h"
#import "Utility.h"
#import "SettingViewController.h"
#import "CollectionViewController.h"
#import "CustomSheet.h"
#import <UMSocialCore/UMSocialCore.h>

@interface MoreViewController () <UITableViewDelegate, UITableViewDataSource, UIActionSheetDelegate, CustomCollectionViewDelegate>

@property (nonatomic, strong) UITableView *tbView;

@end

@implementation MoreViewController

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.backgroundColor = [UIColor clearColor];
    }
    return _tbView;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self changeAppBackgroundStyle];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    [self.view addSubview:self.tbView];
}

- (void)changeAppBackgroundStyle
{
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    self.tabBarController.tabBar.barStyle = [ColorManager manager].tabBar_barStyle;
    self.tabBarController.tabBar.barTintColor = [ColorManager manager].tabBar_barTintColor;
    self.tabBarController.tabBar.tintColor = [ColorManager manager].tabBar_tintColor;
    self.tabBarController.tabBar.backgroundImage = [ColorManager manager].tabBar_backgroundImage;
    self.tabBarController.tabBarItem.image = [ColorManager manager].tabBar_more_image;
    self.tabBarController.tabBarItem.selectedImage = [ColorManager manager].tabBar_more_selectedImage;
    [self.tbView reloadData];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"SettingViewController-cellID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    cell.backgroundColor = [ColorManager manager].cell_backgroundColor;
    cell.textLabel.textColor = [ColorManager manager].cell_textLabel_textColor;
    if (indexPath.section == 0) {
        cell.textLabel.text = @"App设置";
    } else if (indexPath.section == 1) {
        cell.textLabel.text = @"我的收藏";
    } else if (indexPath.section == 2) {
        cell.textLabel.text = @"分享App";
    }
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return 1;
            break;
        case 1:
            return 1;
            break;
        case 2:
            return 1;
            break;
        default:
            return 0;
            break;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return @"设置本地图片缓存、背景模式";
            break;
        case 1:
            return @"查看已收藏的菜谱";
            break;
        case 2:
            return @"分享App给小伙伴吧";
            break;
        default:
            return @"";
            break;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        SettingViewController *settingVC = [[SettingViewController alloc] init];
        [self.navigationController pushViewController:settingVC animated:YES];
    } else if (indexPath.section == 1) {
        CollectionViewController *collectionVC = [[CollectionViewController alloc] init];
        [self.navigationController pushViewController:collectionVC animated:YES];
    } else if (indexPath.section == 2) {
        [CustomSheet shareSheet].collectView.delegate = self;
        [[CustomSheet shareSheet] showAppShare];

    }
}

#pragma mark CustomCollectionView Delegate Method
- (void)customCollectionView:(CustomCollectionView *)customCollectionVeiw didSelectItemAtIndex:(NSInteger)index
{
    [[CustomSheet shareSheet] hide];
    switch (index) {
        case 0:
            [self shareWebPageToPlatformType:UMSocialPlatformType_WechatTimeLine];
            break;
        case 1:
            [self shareWebPageToPlatformType:UMSocialPlatformType_WechatSession];

            break;
        case 2:
            [self shareWebPageToPlatformType:UMSocialPlatformType_Qzone];

            break;
        case 3:
            [self shareWebPageToPlatformType:UMSocialPlatformType_QQ];

            break;
        case 4:
            [self shareWebPageToPlatformType:UMSocialPlatformType_Sina];

            break;
        case 5:
            [self showIOSShareSheet];

            break;
        default:
            break;
    }

}

#pragma mark 分享网页
- (void)shareWebPageToPlatformType:(UMSocialPlatformType)platformType
{
    //创建分享消息对象
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];

    //创建网页内容对象
    UMShareWebpageObject *shareObject = [UMShareWebpageObject shareObjectWithTitle:@"默默食谱" descr:@"周末休闲在家无所事事，该干点什么才不浪费美好的时光呢？不如自己动手做一道菜吧~" thumImage:[UIImage imageNamed:@"appIcon"]];
    //设置网页地址
    shareObject.webpageUrl = @"https://www.zhujizheng.com";

    //分享消息对象设置分享内容对象
    messageObject.shareObject = shareObject;

    //调用分享接口
    [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:self completion:^(id data, NSError *error) {
        if (error) {
            NSLog(@"************Share fail with error %@*********",error);
        }else{
            NSLog(@"response data is %@",data);
        }
    }];
}

#pragma mark 弹出iOS系统自带的分享面板
- (void)showIOSShareSheet
{
    NSLog(@"%s", __FUNCTION__);

    NSArray *activityItems = @[@"title", @"content", [UIImage imageNamed:@"qq"], [NSURL URLWithString:@"https://www.zhujizheng.com"]];
    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:activityItems applicationActivities:nil];
    activityVC.excludedActivityTypes = @[UIActivityTypePostToFacebook,
                                         UIActivityTypePostToTwitter,
                                         UIActivityTypePrint,
                                         UIActivityTypeAssignToContact,
                                         UIActivityTypeSaveToCameraRoll,
                                         UIActivityTypeAddToReadingList,
                                         UIActivityTypePostToFlickr,
                                         UIActivityTypePostToVimeo,
                                         UIActivityTypePostToTencentWeibo,
                                         UIActivityTypeAirDrop];
    [self presentViewController:activityVC animated:YES completion:nil];
    activityVC.completionWithItemsHandler = ^(UIActivityType activityType, BOOL completed, NSArray * returnedItems, NSError * activityError) {
        if (activityType == UIActivityTypePostToWeibo) {
            if (completed) {
                NSLog(@"微博分享已完成");
                
            }
        }
    };
}

@end
