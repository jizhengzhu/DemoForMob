//
//  NSString+shouhangsuojing.m
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "NSString+shouhangsuojing.h"

@implementation NSString (shouhangsuojing)

- (NSAttributedString *)shouhangsuojing:(UIFont *)font {
    NSMutableParagraphStyle *paraStyle = [[NSMutableParagraphStyle alloc] init];
    paraStyle.lineBreakMode = NSLineBreakByCharWrapping;
    
    paraStyle.alignment = NSTextAlignmentLeft;  //对齐
    CGFloat emptylen = font.pointSize * 2;
    paraStyle.firstLineHeadIndent = emptylen;//首行缩进
    paraStyle.lineSpacing = 2.0f;//行间距

    NSAttributedString *attrText = [[NSAttributedString alloc] initWithString:self attributes:@{NSParagraphStyleAttributeName:paraStyle,
                                                                                                NSFontAttributeName:font}];
    return attrText;
}

@end
