//
//  AppDelegate.m
//  MoMoCookRecipe
//
//  Created by F7686324 on 09/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "AppDelegate.h"
#import "JZTabBarController.h"
#import "Utility.h"
#import <UMSocialCore/UMSocialCore.h>

@interface AppDelegate ()

@property (nonatomic, strong) JZTabBarController *tabBarController;
@property (nonatomic, strong) UINavigationController *navi;

@end

@implementation AppDelegate

- (JZTabBarController *)tabBarController
{
    if (!_tabBarController) {
        _tabBarController = [[JZTabBarController alloc] init];
        _tabBarController.navigationItem.title = @"菜谱";
    }
    return _tabBarController;
}

- (UINavigationController *)navi
{
    if (!_navi) {
        _navi = [[UINavigationController alloc] initWithRootViewController:self.tabBarController];
        _navi.navigationBar.barStyle = UIBarStyleBlack;
        _navi.navigationBar.barTintColor = [ColorManager manager].navigationBar_barTintColor;
        _navi.navigationBar.tintColor = [ColorManager manager].navigationBar_tintColor;
        _navi.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[ColorManager manager].navigationBar_titleColor};

    }
    return _navi;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

#pragma mark MobAPI 注册AppKey
    [MobAPI registerApp:MobAPIAppKey];

#pragma mark 设置图片缓存时间和大小
    [SDImageCache sharedImageCache].maxCacheAge = 60 * 60 * 24 * 30;
    [SDImageCache sharedImageCache].maxCacheSize = 1024 * 1024 * 100;

    NSLog(@"daxiao  = %lu", (unsigned long)[SDImageCache sharedImageCache].getSize);
    NSLog(@"count = %lu", (unsigned long)[SDImageCache sharedImageCache].getDiskCount);
#pragma mark 友盟初始化设置
    //打开调试日志
    [[UMSocialManager defaultManager] openLog:YES];

    //设置友盟appkey
    [[UMSocialManager defaultManager] setUmSocialAppkey:UMAppKey];

    // 获取友盟social版本号
    NSLog(@"UMeng social version: %@", [UMSocialGlobal umSocialSDKVersion]);

#pragma mark 初始化微信分享平台
    //设置微信的appKey和appSecret
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_WechatSession appKey:wechatAppID appSecret:wechatAppSecret redirectURL:@"https://www.zhujizheng.com"];

    // 如果不想显示平台下的某些类型，可用以下接口设置
    //    [[UMSocialManager defaultManager] removePlatformProviderWithPlatformTypes:@[@(UMSocialPlatformType_WechatFavorite)]];

#pragma mark 初始化新浪微博分享平台
    //设置新浪的appKey和appSecret
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_Sina appKey:sinaAppKey  appSecret:sinaAppSecret redirectURL:@"https://sns.whalecloud.com/sina2/callback"];

#pragma mark 初始化QQ分享平台
    //设置分享到QQ互联的appKey和appSecret
    // U-Share SDK为了兼容大部分平台命名，统一用appKey和appSecret进行参数设置，而QQ平台仅需将appID作为U-Share的appKey参数传进即可。
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_QQ appKey:qqAppID appSecret:nil redirectURL:@"https://www.zhujizheng.com"];


    if (![NSString valueByKey:keyAppBackgroundStyle]) {
        [@"夜晚" storeValueByKey:keyAppBackgroundStyle];
    }
    if ([[NSString valueByKey:keyAppBackgroundStyle] isEqualToString:@"夜晚"]) {
        [[ColorManager manager] setNightStyle];
    } else {
        [[ColorManager manager] setDayStyle];
    }
    self.window.rootViewController = self.navi;
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;

    return YES;
}

#pragma mark U-Share SDK回调
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    BOOL result = [[UMSocialManager defaultManager] handleOpenURL:url];
    if (!result) {
        // 其他如支付等SDK的回调

    }
    return result;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey, id> *)options
{
    BOOL result = [[UMSocialManager defaultManager] handleOpenURL:url];
    if (!result) {
        // 其他如支付等SDK的回调
    }
    return result;
}

#pragma mark 图片缓存警告
- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{
    [[SDImageCache sharedImageCache] clearMemory];
    [[SDWebImageManager sharedManager] cancelAll];
}


@end
