//
//  JZCookStep.m
//  小助手
//
//  Created by Jim on 2016/12/6.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZCookStep.h"

@implementation JZCookStep

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        if (dict[@"img"]) {
            self.img = [dict[@"img"] stringByReplacingOccurrencesOfString:@"http" withString:@"https"];
        } else {
            self.img = @"";
        }
        
        if (dict[@"step"]) {
            self.step = dict[@"step"];
        } else {
            self.step = @"";
        }
    }
    return self;
}

+ (instancetype)cookStepWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

@end
