//
//  JZModel.h
//  MoMoCookRecipe
//
//  Created by F7686324 on 2016/12/14.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZModel : NSObject

@property (nonatomic, strong) NSString *thumbnail;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *sumary;
@property (nonatomic, strong) NSString *menuId;
@property (nonatomic, strong) NSString *recipe;

+ (instancetype)modelWithThumbnail:(NSString *)thumbnail
                              name:(NSString *)name
                            sumary:(NSString *)sumary
                            menuId:(NSString *)menuId
                            recipe:(NSString *)recipe;

@end
