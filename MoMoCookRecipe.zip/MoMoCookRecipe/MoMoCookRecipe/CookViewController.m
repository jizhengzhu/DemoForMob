//
//  CookViewController.m
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "CookViewController.h"
#import "Utility.h"
#import "CookTableViewCell.h"
#import "JZCookMenu.h"
#import "JZCookRecipe.h"
#import "CookDetailViewController.h"
#import "MJRefresh.h"
#import "JZFmdbTool.h"

@interface CookViewController () <UITableViewDelegate, UITableViewDataSource, UIViewControllerPreviewingDelegate>
{
    NSInteger mjCount;
}
@property (nonatomic, strong) UITableView *tbView;

@property (nonatomic, strong) NSMutableArray *cookMenuArray;
@property (nonatomic, strong) NSMutableArray *cookRecipeArray;

@end

@implementation CookViewController

- (NSMutableArray *)cookMenuArray
{
    if (!_cookMenuArray) {
        _cookMenuArray = [NSMutableArray array];
    }
    return _cookMenuArray;
}

- (NSMutableArray *)cookRecipeArray
{
    if (!_cookRecipeArray) {
        _cookRecipeArray = [NSMutableArray array];

    }
    return _cookRecipeArray;
}

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH) style:UITableViewStylePlain];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.backgroundColor = [UIColor clearColor];
        _tbView.separatorInset = UIEdgeInsetsMake(0, screenW, 0, 0);

    }
    return _tbView;
}

- (void)setCookName:(JZCookName *)cookName
{
    _cookName = cookName;
    self.title = cookName.name;
    NSLog(@"cookName.ctgId = %@", cookName.ctgId);
    NSLog(@"cookName.name = %@", cookName.name);

}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [LCProgressHUD hide];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self changeAppBackgroundStyle];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    [self.view addSubview:self.tbView];
    [self sendRequestWithPage:1 ctgId:self.cookName.ctgId name:nil];

    mjCount = 2;
    [self.cookMenuArray removeAllObjects];
    [self.cookRecipeArray removeAllObjects];
    
    self.tbView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self sendRequestWithPage:mjCount ctgId:self.cookName.ctgId name:nil];
        mjCount++;
    }];
}

- (void)changeAppBackgroundStyle
{
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    [self.tbView reloadData];
}

- (void)sendRequestWithPage:(NSInteger)page ctgId:(NSString *)ctgId name:(NSString *)name
{
    [LCProgressHUD showLoading:@"加载中"];

    [MobAPI sendRequest:[MOBACookRequest searchMenuRequestByCid:ctgId
                                                           name:name
                                                           page:page
                                                           size:20] onResult:^(MOBAResponse *response) {
        [self.tbView.mj_footer endRefreshing];
        if (response.error) {
            if ([response.error.userInfo objectForKey:@"error_message"]) {
                [LCProgressHUD showInfoMsg:[response.error.userInfo objectForKey:@"error_message"]];
                
            } else {
                [LCProgressHUD showInfoMsg:@"网络有点卡..."];
                
            }
            
        } else {
            [LCProgressHUD hide];
            NSLog(@"response success = %@", [response.responder JSONString]);
            
            NSArray *list = [response.responder objectForKey:@"list"];
            if ([list isKindOfClass:[NSArray class]]) {
                if (list.count) {
                    for (NSDictionary *dict in list) {
                        JZCookMenu *cookMenu = [JZCookMenu cookMenuWithDict:dict];
                        JZCookRecipe *cookRecipe = [JZCookRecipe cookRecipeWithDict:cookMenu.recipe];
                        [self.cookMenuArray addObject:cookMenu];
                        [self.cookRecipeArray addObject:cookRecipe];
                    }
                    [self.tbView reloadData];
                } else {
                    [self.tbView.mj_footer endRefreshingWithNoMoreData];
                }
            } else {
                [self.tbView.mj_footer endRefreshingWithNoMoreData];

            }


        }
    }];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CookTableViewCell *cell = [CookTableViewCell cellWithTableView:tableView];
    JZCookRecipe *cookRecipe = self.cookRecipeArray[indexPath.row];
    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    NSLog(@"cookMenu.thumbnail = %@", cookMenu.thumbnail);
    [cell.imgView sd_setImageWithURL:[NSURL URLWithString:cookMenu.thumbnail] placeholderImage:[UIImage imageNamed:@"replaceImage"]];

    cell.name.text = cookMenu.name;
    cell.sumary.text = cookRecipe.sumary;
    if (self.traitCollection.forceTouchCapability == UIForceTouchCapabilityAvailable) {
        [self registerForPreviewingWithDelegate:self sourceView:cell];
    }
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.cookMenuArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    CookDetailViewController *cookDetailVC = [[CookDetailViewController alloc] init];

    JZCookRecipe *cookRecipe = self.cookRecipeArray[indexPath.row];
    cookDetailVC.cookRecipe = cookRecipe;

    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    cookDetailVC.cookMenu = cookMenu;

    [self.navigationController pushViewController:cookDetailVC animated:YES];
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    JZCookRecipe *cookRecipe = self.cookRecipeArray[indexPath.row];

    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSString *value = [self distinguishCollectionStatusByCookMenu:cookMenu];
        [self distinguishCollecionOperationByValue:value cookMenu:cookMenu cookRecipe:cookRecipe];
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {

    }
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    NSString *value = [self distinguishCollectionStatusByCookMenu:cookMenu];

    return value;
}
#pragma mark 鉴别是否收藏
- (NSString *)distinguishCollectionStatusByCookMenu:(JZCookMenu *)cookMenu
{
    NSString *querySql = [NSString stringWithFormat:@"SELECT * FROM jz_models WHERE menuId = '%@'", cookMenu.menuId];
    NSArray *arr = [JZFmdbTool queryData:querySql];

    NSString *value = @"收藏";
    if (arr.count) {
        value = @"取消收藏";
    }

    return value;
}

#pragma mark 根据收藏状态执行相应操作
- (void)distinguishCollecionOperationByValue:(NSString *)value cookMenu:(JZCookMenu *)cookMenu cookRecipe:(JZCookRecipe *)cookRecipe
{
    if ([value isEqualToString:@"收藏"]) {
        JZModel *model = [JZModel modelWithThumbnail:cookMenu.thumbnail
                                                name:cookMenu.name
                                              sumary:cookRecipe.sumary
                                              menuId:cookMenu.menuId
                                              recipe:[cookMenu.recipe JSONString]];
        [JZFmdbTool insertModel:model];
        [LCProgressHUD showInfoMsg:@"收藏成功"];
    } else if ([value isEqualToString:@"取消收藏"]) {
        NSString *deleteSql = [NSString stringWithFormat:@"DELETE FROM jz_models WHERE menuId = '%@'", cookMenu.menuId];
        [JZFmdbTool deleteData:deleteSql];
        [LCProgressHUD showInfoMsg:@"取消收藏成功"];
    }
}

#pragma mark UIViewControllerPreviewingDelegate Methods
//peek(预览)
- (nullable UIViewController *)previewingContext:(id<UIViewControllerPreviewing>)previewingContext viewControllerForLocation:(CGPoint)location
{
    //获取按压的cell所在行， [previewingContext sourceView]就是按压的那个视图
    NSIndexPath *indexPath = [self.tbView indexPathForCell:(UITableViewCell *)[previewingContext sourceView]];

    //设定预览的界面
    CookDetailViewController *cookDetailVC = [[CookDetailViewController alloc] init];
    JZCookRecipe *cookRecipe = self.cookRecipeArray[indexPath.row];
    cookDetailVC.cookRecipe = cookRecipe;

    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    cookDetailVC.cookMenu = cookMenu;

    //调整不被虚化的范围，按压的那个cell不被虚化（轻轻按压时周边会被虚化，再稍用力展示预览，再加力跳页至设定界面)
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width, 80);
    previewingContext.sourceRect = rect;

    //返回预览界面
    return cookDetailVC;
}

//pop (再加力进入)
- (void)previewingContext:(id<UIViewControllerPreviewing>)previewingContext commitViewController:(UIViewController *)viewControllerToCommit
{
    [self showViewController:viewControllerToCommit sender:self];
}
@end
