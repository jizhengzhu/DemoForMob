//
//  JZTabBarController.m
//  CookRecipe
//
//  Created by F7686324 on 07/12/2016.
//  Copyright © 2016 Jim.com. All rights reserved.
//

#import "JZTabBarController.h"
#import "MainViewController.h"
#import "MoreViewController.h"
#import "Utility.h"
@interface JZTabBarController ()

@property (nonatomic, strong) MainViewController *mainVC;
@property (nonatomic, strong) MoreViewController *moreVC;

@end

@implementation JZTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    _mainVC = [[MainViewController alloc] init];
    _mainVC.tabBarItem.title = @"菜谱";
    _mainVC.tabBarItem.image = [ColorManager manager].tabBar_cook_image;
    _mainVC.tabBarItem.selectedImage = [ColorManager manager].tabBar_cook_selectedImage;

    _moreVC = [[MoreViewController alloc] init];
    _moreVC.tabBarItem.title = @"更多";
    _moreVC.tabBarItem.image = [ColorManager manager].tabBar_more_image;
    _moreVC.tabBarItem.selectedImage = [ColorManager manager].tabBar_more_selectedImage;

    self.tabBar.backgroundImage = [ColorManager manager].tabBar_backgroundImage;
    self.tabBar.barStyle = [ColorManager manager].tabBar_barStyle;
    self.tabBar.translucent = YES;
    self.tabBar.itemPositioning = UITabBarItemPositioningFill;
    self.tabBar.barTintColor = [ColorManager manager].tabBar_barTintColor;
    self.tabBar.tintColor = [ColorManager manager].tabBar_tintColor;
    self.delegate = self;
    self.viewControllers = @[_mainVC, _moreVC];

}

#pragma mark 代理

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
    NSLog(@"%s", __FUNCTION__);
    if (self.selectedIndex == 0) {
        self.navigationItem.title = @"菜谱";
    } else if (self.selectedIndex == 1) {
        tabBarController.navigationItem.title = @"更多";
    }
}


@end
