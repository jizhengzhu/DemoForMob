//
//  CookDetailFrame.h
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "JZCookRecipe.h"
#import "Utility.h"

@interface CookDetailFrame : NSObject

@property (nonatomic, strong) NSMutableArray *frameArray;

- (instancetype)initWithCookRecipe:(JZCookRecipe *)cookRecipe;
+ (instancetype)cookDetailFrameWithCookRecipe:(JZCookRecipe *)cookRecipe;

@end
