//
//  CookDetailFrame.m
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "CookDetailFrame.h"
#import "JZCookStep.h"

@implementation CookDetailFrame
static CGFloat margin = 10;
- (NSMutableArray *)frameArray
{
    if (!_frameArray) {
        _frameArray = [NSMutableArray array];
    }
    return _frameArray;
}

- (instancetype)initWithCookRecipe:(JZCookRecipe *)cookRecipe
{
    if (self = [super init]) {
        [self.frameArray removeAllObjects];

  
        [self.frameArray addObject:[self frameWithString:cookRecipe.title font:[UIFont systemFontOfSize:20] suojin:NO]];
        
        [self.frameArray addObject:[self frameWithString:cookRecipe.sumary font:[UIFont systemFontOfSize:17] suojin:YES]];
        
        [self.frameArray addObject:NSStringFromCGRect(CGRectZero)];
        
        [self.frameArray addObject:[self frameWithString:cookRecipe.ingredients font:[UIFont systemFontOfSize:17] suojin:NO]];
        
        for (NSDictionary *dict in cookRecipe.method) {
            JZCookStep *cookStep = [JZCookStep cookStepWithDict:dict];

            [self.frameArray addObject:[self frameWithString:cookStep.step font:[UIFont systemFontOfSize:17] suojin:NO]];
            [self.frameArray addObject:NSStringFromCGRect(CGRectZero)];
        }
        
    }
    return self;
}

+ (instancetype)cookDetailFrameWithCookRecipe:(JZCookRecipe *)cookRecipe
{
    return [[self alloc] initWithCookRecipe:cookRecipe];
}

- (NSString *)frameWithString:(NSString *)string font:(UIFont *)font suojin:(BOOL)suojin
{
    NSMutableParagraphStyle *paragraphStyle = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    paragraphStyle.lineBreakMode = NSLineBreakByCharWrapping;
    if (suojin) {
        paragraphStyle.firstLineHeadIndent = font.pointSize * 2;//首行缩进
        paragraphStyle.lineSpacing = 2.0f;//行间距
    }
    NSDictionary *attribute = @{
                                NSFontAttributeName:font,
                                NSParagraphStyleAttributeName:paragraphStyle
                                };
    CGSize stringSize = [string boundingRectWithSize:CGSizeMake(screenW * 0.9, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:attribute context:nil].size;

    CGFloat x = screenW * 0.05;
    CGFloat y = margin;
    CGFloat w = screenW * 0.9;
    CGFloat h = stringSize.height;
    CGRect frame = CGRectMake(x, y, w, h);
    return NSStringFromCGRect(frame);
}



@end
