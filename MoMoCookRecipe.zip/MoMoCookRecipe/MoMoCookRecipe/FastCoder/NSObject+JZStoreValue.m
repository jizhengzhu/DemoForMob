//
//  NSObject+JZStoreValue.m
//  tf02
//
//  Created by Jim on 16/8/22.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "NSObject+JZStoreValue.h"

@implementation NSObject (JZStoreValue)

- (void)storeValueByKey:(NSString *)key {
    
    [[JZStoreValue shareInstance] storeValue:self withKey:key];
}

+ (id)valueByKey:(NSString *)key {
    
    return [[JZStoreValue shareInstance] valueWithKey: key];
}

@end
