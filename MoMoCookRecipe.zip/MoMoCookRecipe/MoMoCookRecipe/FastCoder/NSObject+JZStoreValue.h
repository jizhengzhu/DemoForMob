//
//  NSObject+JZStoreValue.h
//  tf02
//
//  Created by Jim on 16/8/22.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JZStoreValue.h"

@interface NSObject (JZStoreValue)

- (void)storeValueByKey: (NSString *)key;
+ (id)valueByKey: (NSString *)key;

@end
