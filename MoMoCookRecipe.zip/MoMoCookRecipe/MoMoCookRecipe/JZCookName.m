//
//  JZCookName.m
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZCookName.h"

@implementation JZCookName

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if(self = [super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)cookNameWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

@end
