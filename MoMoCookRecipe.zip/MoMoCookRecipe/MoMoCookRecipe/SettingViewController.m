//
//  SettingViewController.m
//  CookRecipe
//
//  Created by F7686324 on 07/12/2016.
//  Copyright © 2016 Jim.com. All rights reserved.
//

#import "SettingViewController.h"
#import "Utility.h"
#import "CustomSheet.h"

@interface SettingViewController () <UITableViewDelegate, UITableViewDataSource, CustomTableViewDelegate>

@property (nonatomic, strong) UITableView *tbView;

@end

@implementation SettingViewController


- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH) style:UITableViewStyleGrouped];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.backgroundColor = [UIColor clearColor];
    }
    return _tbView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"App设置";
    self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    self.tbView.indicatorStyle = [ColorManager manager].tbView_indicatorStyle;
    [self.view addSubview:self.tbView];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"SelectStyleViewController-cellID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellid];

    }
    cell.backgroundColor = [ColorManager manager].cell_backgroundColor;
    cell.textLabel.textColor = [ColorManager manager].cell_textLabel_textColor;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    if (indexPath.section == 0) {
        cell.textLabel.text = @"模式";
        cell.detailTextLabel.text = [NSString valueByKey:keyAppBackgroundStyle];
    } else if (indexPath.section == 1) {
        cell.textLabel.text = @"本地缓存";
        float number = (float)[SDImageCache sharedImageCache].getSize;
        float space = 1;
        NSArray *arr = @[@"b", @"k", @"M", @"G"];
        for (int i = 0; i < 4; i++) {
            space *= 1024.f;
            if (number < space) {
                float value = number * 1024.f / space;
                cell.detailTextLabel.text = [NSString stringWithFormat:@"%0.1f %@", value, arr[i]];
                break;
            }
        }
    }


    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;

}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return @"选择App界面的背景模式";
            break;
        case 1:
            return @"清除本地缓存的图片";
        default:
            return @"";
            break;
    }

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        [CustomSheet shareSheet].tableView.delegate = self;
        [[CustomSheet shareSheet] showBackgroundStyleSheet];
    } else if (indexPath.section == 1) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:@"您确定要清除本地缓存的图片吗" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [[SDImageCache sharedImageCache] clearDisk];
            [self.tbView reloadData];
        }];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        [alertController addAction:okAction];
        [alertController addAction:cancelAction];
        [self presentViewController:alertController animated:YES completion:nil];
    }

}

#pragma mark CustomTableVeiw delegate method
- (void)customTableView:(CustomTableView *)customTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[CustomSheet shareSheet] hide];
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            [@"夜晚" storeValueByKey:keyAppBackgroundStyle];
            [[ColorManager manager] setNightStyle];


        } else if (indexPath.row == 1) {
            [@"白天" storeValueByKey:keyAppBackgroundStyle];
            [[ColorManager manager] setDayStyle];
        }
        self.view.backgroundColor = [ColorManager manager].app_backgroundColor;
        self.navigationController.navigationBar.barTintColor = [ColorManager manager].navigationBar_barTintColor;
        self.navigationController.navigationBar.tintColor = [ColorManager manager].navigationBar_tintColor;
        self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[ColorManager manager].navigationBar_titleColor};
        self.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
        [self.tbView reloadData];
    }
}

@end
