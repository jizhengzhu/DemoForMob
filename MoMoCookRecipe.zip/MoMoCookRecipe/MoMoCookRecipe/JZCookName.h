//
//  JZCookName.h
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZCookName : NSObject

@property (nonatomic, copy) NSString *ctgId;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *parentId;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)cookNameWithDict:(NSDictionary *)dict;

@end
