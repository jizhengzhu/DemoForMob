//
//  CustomCollectionViewLayout.h
//  CookRecipe
//
//  Created by Jim on 2016/12/8.
//  Copyright © 2016年 Jim.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCollectionViewLayout : UICollectionViewFlowLayout

@end
