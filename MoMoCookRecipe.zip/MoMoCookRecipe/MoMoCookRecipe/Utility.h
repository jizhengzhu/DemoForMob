//
//  Utility.h
//  小助手
//
//  Created by Jim on 2016/12/5.
//  Copyright © 2016年 Jim. All rights reserved.
//

#ifndef Utility_h
#define Utility_h

#import "AFNManagerRequest.h"

#import <MobAPI/MobAPI.h>

#import "UIImageView+WebCache.h"

#import "NSObject+JZStoreValue.h"

#import "ColorManager.h"

#define MobAPIAppKey @"19a342ebdc6aa"
#define MobAPIAppSecret @"36cc77a80a82c84e8a8287a0242aee05"

#define ShareAppKey @"19be21698db36"
#define ShareAppSecret @"99d199bf0e7dcbcaf6c0f375a79ff3d3"

#define UMAppKey @"58495f37677baa7b010020a1"

#define wechatAppID @"wxafee2d52312c16b8"
#define wechatAppSecret @"b0dce4010714796f11411673a85c9057"

#define qqAppID @"1105800069"
#define qqAppKey @"0EowW8lwHhX4Ake8"


#define sinaAppKey @"2500382326"
#define sinaAppSecret @"e9843c14c907b863561b333271f64c93"

// 电话号码归属地查询
#define phoneNumberURL @"https://apicloud.mob.com/v1/mobile/address/query"

// 菜谱分类标签查询
#define cookCategoryQueryURL @"https://apicloud.mob.com/v1/cook/category/query"
// 按标签查询菜谱
#define cookMenuSearchURL @"https://apicloud.mob.com/v1/cook/menu/search"
// 菜谱详情查询
#define cookMenuQueryURL @"https://apicloud.mob.com/v1/cook/menu/query"

#define screenW [UIScreen mainScreen].bounds.size.width
#define screenH [UIScreen mainScreen].bounds.size.height
#define statusHeight 20
#define naviHeight 44
#define tabBarHeight 49

#define nightTintColor [UIColor orangeColor]
#define nightBarBackgroundColor [UIColor colorWithWhite:0.1 alpha:1]
#define nightBackgroundColor [UIColor blackColor]

#define dayTintColor [UIColor blueColor]
#define dayBarBackgroundColor [UIColor whiteColor]
#define dayBackgroundColor [UIColor colorWithWhite:0.9 alpha:1];

#define GoldColor [UIColor colorWithRed:1 green:0.8 blue:0 alpha:1]

#define keyAppBackgroundStyle @"keyAppBackgroundStyle"

#define updateCollectionNotification @"updateCollectionNotification"

#endif /* Utility_h */
