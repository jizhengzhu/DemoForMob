//
//  SearchView.m
//  CookRecipe
//
//  Created by F7686324 on 07/12/2016.
//  Copyright © 2016 Jim.com. All rights reserved.
//

#import "SearchView.h"

@implementation SearchView

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:self.bounds];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.separatorInset = UIEdgeInsetsMake(0, screenW, 0, 0);
        _tbView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
        _tbView.backgroundColor = [UIColor clearColor];
    }
    return _tbView;
}

- (UIVisualEffectView *)visualEffectView
{
    if (!_visualEffectView) {
        _visualEffectView = [[UIVisualEffectView alloc] initWithFrame:self.bounds];
        _visualEffectView.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    }
    return _visualEffectView;
}

- (void)setCookMenuArray:(NSMutableArray *)cookMenuArray
{
    _cookMenuArray = cookMenuArray;
}

- (void)setCookRecipeArray:(NSMutableArray *)cookRecipeArray
{
    _cookRecipeArray = cookRecipeArray;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

        [self addSubview:self.visualEffectView];
        [self addSubview:self.tbView];
    }
    return self;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CookTableViewCell *cell = [CookTableViewCell cellWithTableView:tableView];
    JZCookRecipe *cookRecipe = self.cookRecipeArray[indexPath.row];
    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    [cell.imgView sd_setImageWithURL:[NSURL URLWithString:cookMenu.thumbnail] placeholderImage:[UIImage imageNamed:@"replaceImage"]];
    cell.name.text = cookMenu.name;
    cell.sumary.text = cookRecipe.sumary;
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.cookMenuArray.count;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.delegate searchView:self didSelectRowAtIndexPath:indexPath];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    JZCookRecipe *cookRecipe = self.cookRecipeArray[indexPath.row];
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSString *value = [self distinguishCollectionStatusByCookMenu:cookMenu];
        [self distinguishCollecionOperationByValue:value cookMenu:cookMenu cookRecipe:cookRecipe];
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JZCookMenu *cookMenu = self.cookMenuArray[indexPath.row];
    NSString *value = [self distinguishCollectionStatusByCookMenu:cookMenu];
    
    return value;
}
#pragma mark 鉴别是否收藏
- (NSString *)distinguishCollectionStatusByCookMenu:(JZCookMenu *)cookMenu
{
    NSString *querySql = [NSString stringWithFormat:@"SELECT * FROM jz_models WHERE menuId = '%@'", cookMenu.menuId];
    NSArray *arr = [JZFmdbTool queryData:querySql];
    
    NSString *value = @"收藏";
    if (arr.count) {
        value = @"取消收藏";
    }
    
    return value;
}

#pragma mark 根据收藏状态执行相应操作
- (void)distinguishCollecionOperationByValue:(NSString *)value cookMenu:(JZCookMenu *)cookMenu cookRecipe:(JZCookRecipe *)cookRecipe
{
    if ([value isEqualToString:@"收藏"]) {
        JZModel *model = [JZModel modelWithThumbnail:cookMenu.thumbnail
                                                name:cookMenu.name
                                              sumary:cookRecipe.sumary
                                              menuId:cookMenu.menuId
                                              recipe:[cookMenu.recipe JSONString]];
        [JZFmdbTool insertModel:model];
        [LCProgressHUD showInfoMsg:@"收藏成功"];
    } else if ([value isEqualToString:@"取消收藏"]) {
        NSString *deleteSql = [NSString stringWithFormat:@"DELETE FROM jz_models WHERE menuId = '%@'", cookMenu.menuId];
        [JZFmdbTool deleteData:deleteSql];
        [LCProgressHUD showInfoMsg:@"取消收藏成功"];
    }
}


@end
