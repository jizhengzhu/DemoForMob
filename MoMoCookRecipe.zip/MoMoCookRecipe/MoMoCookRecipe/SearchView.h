//
//  SearchView.h
//  CookRecipe
//
//  Created by F7686324 on 07/12/2016.
//  Copyright © 2016 Jim.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CookTableViewCell.h"
#import "UIImageView+WebCache.h"
#import "JZCookRecipe.h"
#import "JZCookMenu.h"
#import "Utility.h"
#import "JZFmdbTool.h"
#import "CookDetailViewController.h"


@class SearchView;
@protocol SearchViewDelegate <NSObject>

@required
- (void)searchView:(SearchView *)searchView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface SearchView : UIView <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, weak) id <SearchViewDelegate> delegate;
@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, strong) UIVisualEffectView *visualEffectView;

@property (nonatomic, strong) NSMutableArray *cookMenuArray;
@property (nonatomic, strong) NSMutableArray *cookRecipeArray;

@end
