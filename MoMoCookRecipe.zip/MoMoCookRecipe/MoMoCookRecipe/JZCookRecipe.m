//
//  JZCookRecipe.m
//  小助手
//
//  Created by F7686324 on 06/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZCookRecipe.h"

@implementation JZCookRecipe

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        if (dict[@"img"]) {
            self.img = [dict[@"img"] stringByReplacingOccurrencesOfString:@"http" withString:@"https"];
        } else {
            self.img = @"";
        }

        if ([dict[@"method"] isKindOfClass:[NSArray class]]) {
            self.method = dict[@"method"];
        } else {
            self.method = [NSArray array];
        }

        if (dict[@"ingredients"]) {
            self.ingredients = dict[@"ingredients"];
        } else {
            self.ingredients = @"";
        }

        if (dict[@"title"]) {
            self.title = dict[@"title"];
        } else {
            self.title = @"";
        }

        if (dict[@"sumary"]) {
            self.sumary = dict[@"sumary"];
        } else {
            self.sumary = @"";
        }
    }
    return self;
}

+ (instancetype)cookRecipeWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}
@end
