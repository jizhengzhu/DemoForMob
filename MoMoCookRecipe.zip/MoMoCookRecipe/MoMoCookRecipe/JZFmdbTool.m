//
//  JZFmdbTool.m
//  MoMoCookRecipe
//
//  Created by F7686324 on 2016/12/14.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZFmdbTool.h"
#import "JZModel.h"

#define JZSQLITE_NAME @"jz_models.sqlite"

@implementation JZFmdbTool

static FMDatabase *_fmdb;

+ (void)initialize
{
    // 执行打开数据库和创建表的操作
    NSString *filePath = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject] stringByAppendingPathComponent:JZSQLITE_NAME];

    _fmdb = [FMDatabase databaseWithPath:filePath];

    [_fmdb open];
    //必须先打开数据库才能创建表，否则提示数据库没有打开
    [_fmdb executeUpdate:@"CREATE TABLE IF NOT EXISTS jz_models(menuId TEXT PRIMARY KEY, name TEXT NULL, thumbnail TEXT NULL, sumary TEXT NULL, recipe TEXT NULL);"];
}

+ (BOOL)insertModel:(JZModel *)model
{
    NSString *insertSql = [NSString stringWithFormat:@"INSERT INTO jz_models(thumbnail, sumary, name, menuId, recipe) VALUES ('%@', '%@', '%@', '%@', '%@');", model.thumbnail, model.sumary, model.name, model.menuId, model.recipe];
    return [_fmdb executeUpdate:insertSql];
}

+ (NSArray *)queryData:(NSString *)querySql 
{
    if (querySql == nil) {
        querySql = @"SELECT * FROM jz_models";
    }

    NSMutableArray *arrM = [NSMutableArray array];
    FMResultSet *set = [_fmdb executeQuery:querySql];

    while ([set next]) {
        NSString *thumbnail = [set stringForColumn:@"thumbnail"];
        NSString *name = [set stringForColumn:@"name"];
        NSString *sumary = [set stringForColumn:@"sumary"];
        NSString *menuId = [set stringForColumn:@"menuId"];
        NSString *recipe = [set stringForColumn:@"recipe"];

        JZModel *model = [JZModel modelWithThumbnail:thumbnail name:name sumary:sumary menuId:menuId recipe:recipe];
        [arrM addObject:model];
    }
    return arrM;
}

+ (BOOL)deleteData:(NSString *)deleteSql
{
    if (deleteSql == nil) {
        deleteSql = @"DELETE FROM jz_models";
    }
    return [_fmdb executeUpdate:deleteSql];
}

+ (BOOL)modifyData:(NSString *)modifySql
{
    if (modifySql == nil) {
        modifySql = @"UPDATE jz_models SET sumary = '暂无简介~' WHERE sumary = ''";
    }
    return [_fmdb executeUpdate:modifySql];
}

@end
