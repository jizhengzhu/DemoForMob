//
//  CustomSheet.m
//  CookRecipe
//
//  Created by Jim on 2016/12/8.
//  Copyright © 2016年 Jim.com. All rights reserved.
//

#import "CustomSheet.h"
#import "CustomCollectionView.h"
#import "Utility.h"

@interface CustomSheet ()
{
    CGFloat collectViewHeight;
    CGFloat tableViewHeight;
    CGFloat duration;
}
@property (nonatomic, strong) UIToolbar *toolbar;
@property (nonatomic, strong) UIView *bgView;

@end

@implementation CustomSheet

+ (CustomSheet *)shareSheet
{
    static CustomSheet *sheet;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sheet = [[CustomSheet alloc] initWithFrame:[UIApplication sharedApplication].keyWindow.bounds];
    });
    return sheet;
}

- (CustomCollectionView *)collectView
{
    if (!_collectView) {
        _collectView = [[CustomCollectionView alloc] initWithFrame:CGRectMake(0, 0, screenW, collectViewHeight)];
    }
    return _collectView;
}

- (CustomTableView *)tableView
{
    if (!_tableView) {
        _tableView = [[CustomTableView alloc] initWithFrame:CGRectMake(0, 0, screenW, tableViewHeight)];
    }
    return _tableView;
}

- (UIToolbar *)toolbar
{
    if (!_toolbar) {
        _toolbar = [[UIToolbar alloc] init];
    }
    return _toolbar;
}

- (UIView *)bgView
{
    if (!_bgView) {
        _bgView = [[UIView alloc] initWithFrame:self.bounds];
        _bgView.backgroundColor = [UIColor clearColor];
    }
    return _bgView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        collectViewHeight = 161;
        tableViewHeight = 160;
        duration = 0.3;
        [self addSubview:self.bgView];
        [self addSubview:self.toolbar];
    }
    return self;
}

- (void)showAppShare
{
//    self.collectView.backgroundColor = [ColorManager manager].cell_backgroundColor;
    self.toolbar.barStyle = [ColorManager manager].sheet_share_barStyle;
    self.toolbar.frame = CGRectMake(0, screenH, screenW, collectViewHeight);
    [self.toolbar addSubview:self.collectView];

    [[UIApplication sharedApplication].keyWindow addSubview:self];
    [UIView animateWithDuration:duration animations:^{
        self.bgView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        self.toolbar.transform = CGAffineTransformMakeTranslation(0, -collectViewHeight);
    }];
}

- (void)showBackgroundStyleSheet
{
    self.tableView.tbView.separatorColor = [ColorManager manager].tbView_separatorColor;
    [self.tableView.tbView reloadData];
//    self.tableView.backgroundColor = [ColorManager manager].app_backgroundColor;
    self.toolbar.frame = CGRectMake(0, screenH, screenW, tableViewHeight);
    self.toolbar.barStyle = [ColorManager manager].sheet_share_barStyle;
    [self.toolbar addSubview:self.tableView];

    [[UIApplication sharedApplication].keyWindow addSubview:self];
    [UIView animateWithDuration:duration animations:^{
        self.bgView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        self.toolbar.transform = CGAffineTransformMakeTranslation(0, -tableViewHeight);
    }];
}

- (void)hide
{
    [UIView animateWithDuration:duration animations:^{
        self.bgView.backgroundColor = [UIColor clearColor];
        self.toolbar.transform = CGAffineTransformIdentity;
    } completion:^(BOOL finished) {
        [self.collectView removeFromSuperview];
        [self.tableView removeFromSuperview];
        [self removeFromSuperview];
    }];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self hide];
}
@end
